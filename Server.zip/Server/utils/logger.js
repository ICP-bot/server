import fs from 'fs/promises';
import path from 'path';

/**
 * Logger utility with file and console output
 */
class Logger {
    constructor(options = {}) {
        this.level = options.level || 'info';
        this.fileEnabled = options.fileEnabled || false;
        this.filePath = options.filePath || './logs/server.log';
        this.levels = {
            error: 0,
            warn: 1,
            info: 2,
            debug: 3
        };
    }

    async initialize() {
        if (this.fileEnabled) {
            const dir = path.dirname(this.filePath);
            await fs.mkdir(dir, { recursive: true });
        }
    }

    async log(level, message, meta = {}) {
        if (this.levels[level] > this.levels[this.level]) {
            return;
        }

        const timestamp = new Date().toISOString();
        const logEntry = {
            timestamp,
            level,
            message,
            ...meta
        };

        // Console output with colors
        const colors = {
            error: '\x1b[31m',
            warn: '\x1b[33m',
            info: '\x1b[36m',
            debug: '\x1b[90m'
        };
        const reset = '\x1b[0m';
        const color = colors[level] || '';

        console.log(`${color}[${timestamp}] [${level.toUpperCase()}]${reset} ${message}`, meta);

        // File output
        if (this.fileEnabled) {
            try {
                await fs.appendFile(this.filePath, JSON.stringify(logEntry) + '\n');
            } catch (error) {
                console.error('Failed to write to log file:', error);
            }
        }
    }

    error(message, meta) {
        return this.log('error', message, meta);
    }

    warn(message, meta) {
        return this.log('warn', message, meta);
    }

    info(message, meta) {
        return this.log('info', message, meta);
    }

    debug(message, meta) {
        return this.log('debug', message, meta);
    }

    async getLogs(options = {}) {
        if (!this.fileEnabled) {
            return [];
        }

        try {
            const content = await fs.readFile(this.filePath, 'utf-8');
            const lines = content.trim().split('\n').filter(Boolean);
            let logs = lines.map(line => JSON.parse(line));

            // Filter by level
            if (options.level) {
                logs = logs.filter(log => log.level === options.level);
            }

            // Filter by time range
            if (options.startTime) {
                logs = logs.filter(log => new Date(log.timestamp) >= new Date(options.startTime));
            }
            if (options.endTime) {
                logs = logs.filter(log => new Date(log.timestamp) <= new Date(options.endTime));
            }

            // Search
            if (options.search) {
                logs = logs.filter(log =>
                    log.message.toLowerCase().includes(options.search.toLowerCase())
                );
            }

            // Limit
            if (options.limit) {
                logs = logs.slice(-options.limit);
            }

            return logs;
        } catch (error) {
            console.error('Failed to read logs:', error);
            return [];
        }
    }

    async clearLogs() {
        if (this.fileEnabled) {
            try {
                await fs.writeFile(this.filePath, '');
            } catch (error) {
                console.error('Failed to clear logs:', error);
            }
        }
    }
}

export default Logger;
