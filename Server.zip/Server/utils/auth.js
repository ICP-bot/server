import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';

/**
 * Authentication utilities
 */
class AuthUtils {
    constructor(jwtSecret, jwtExpiresIn = '24h') {
        this.jwtSecret = jwtSecret;
        this.jwtExpiresIn = jwtExpiresIn;
    }

    /**
     * Hash password
     */
    async hashPassword(password) {
        const salt = await bcrypt.genSalt(10);
        return bcrypt.hash(password, salt);
    }

    /**
     * Compare password
     */
    async comparePassword(password, hash) {
        return bcrypt.compare(password, hash);
    }

    /**
     * Generate JWT token
     */
    generateToken(payload) {
        return jwt.sign(payload, this.jwtSecret, {
            expiresIn: this.jwtExpiresIn
        });
    }

    /**
     * Verify JWT token
     */
    verifyToken(token) {
        try {
            return jwt.verify(token, this.jwtSecret);
        } catch (error) {
            throw new Error('Invalid or expired token');
        }
    }

    /**
     * Generate API key
     */
    generateApiKey(prefix = 'sk') {
        const random = crypto.randomBytes(32).toString('hex');
        return `${prefix}_${random}`;
    }

    /**
     * Generate session token
     */
    generateSessionToken() {
        return crypto.randomBytes(48).toString('hex');
    }

    /**
     * Hash API key for storage
     */
    hashApiKey(apiKey) {
        return crypto.createHash('sha256').update(apiKey).digest('hex');
    }

    /**
     * Verify API key
     */
    verifyApiKey(apiKey, hashedKey) {
        const hash = this.hashApiKey(apiKey);
        return hash === hashedKey;
    }
}

/**
 * Express middleware for JWT authentication
 */
export function authenticateJWT(authUtils) {
    return (req, res, next) => {
        const authHeader = req.headers.authorization;

        if (!authHeader) {
            return res.status(401).json({ error: 'No authorization header' });
        }

        const token = authHeader.split(' ')[1];

        try {
            const decoded = authUtils.verifyToken(token);
            req.user = decoded;
            next();
        } catch (error) {
            return res.status(403).json({ error: 'Invalid or expired token' });
        }
    };
}

/**
 * Express middleware for API key authentication
 */
export function authenticateApiKey(db) {
    return async (req, res, next) => {
        const apiKey = req.headers['x-api-key'];

        if (!apiKey) {
            return res.status(401).json({ error: 'No API key provided' });
        }

        try {
            // Find app by API key
            const apps = await db.find('apps', {});
            const app = apps.find(a => a.apiKey === apiKey);

            if (!app) {
                return res.status(403).json({ error: 'Invalid API key' });
            }

            if (!app.active) {
                return res.status(403).json({ error: 'App is disabled' });
            }

            req.app = app;
            next();
        } catch (error) {
            return res.status(500).json({ error: 'Authentication failed' });
        }
    };
}

/**
 * Express middleware for role-based access control
 */
export function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'Not authenticated' });
        }

        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Insufficient permissions' });
        }

        next();
    };
}

/**
 * Express middleware for rate limiting per user/app
 */
export function createRateLimiter(maxRequests = 100, windowMs = 60000) {
    const requests = new Map();

    return (req, res, next) => {
        const identifier = req.user?.id || req.app?.id || req.ip;
        const now = Date.now();

        if (!requests.has(identifier)) {
            requests.set(identifier, []);
        }

        const userRequests = requests.get(identifier);

        // Remove old requests outside window
        const validRequests = userRequests.filter(time => now - time < windowMs);

        if (validRequests.length >= maxRequests) {
            return res.status(429).json({
                error: 'Too many requests',
                retryAfter: Math.ceil((validRequests[0] + windowMs - now) / 1000)
            });
        }

        validRequests.push(now);
        requests.set(identifier, validRequests);

        next();
    };
}

export default AuthUtils;
