# Universal Node.js Server

A comprehensive, production-ready Node.js server with custom database, AI integration, realtime features, and admin panel. Perfect for building multi-tenant applications with zero external database dependencies.

## 🌟 Features

### Core Features
- ✅ **Pure Node.js** - No external database required
- ✅ **Custom Internal Database** - JSON/Binary/In-Memory storage with disk persistence
- ✅ **AI Integration** - Hugging Face API for schema generation and suggestions
- ✅ **Realtime Engine** - WebSocket/Socket.IO for live updates
- ✅ **REST API** - Complete RESTful API with versioning
- ✅ **Admin Panel** - Beautiful Bootstrap 5 UI for management
- ✅ **Multi-Tenant** - Support for multiple apps on same server
- ✅ **Wasmer Edge Compatible** - Can be deployed to edge environments

### Database Features
- CRUD operations with indexing
- Query support with operators ($eq, $gt, $in, etc.)
- Realtime sync across connections
- Automatic backup and restore
- Import/Export functionality
- Schema validation
- Encryption support (AES-256)
- In-memory caching with periodic persistence

### Security Features
- JWT authentication
- API key management
- Role-based access control (RBAC)
- Rate limiting
- Password hashing (bcrypt)
- Audit logging
- File encryption

### AI Features
- Auto database schema generation from prompts
- API endpoint generation
- SDK/JSON configuration generation
- Optimization suggestions
- Security recommendations
- Complete app generation from description

### Realtime Features
- WebSocket connections
- Presence/status updates
- Real-time messaging
- Call signaling (WebRTC compatible)
- Database change notifications
- Custom event broadcasting

## 📋 Requirements

- Node.js >= 18.0.0
- npm or yarn

## 🚀 Quick Start

### 1. Installation

```bash
# Clone or download the project
cd Server

# Install dependencies
npm install
```

### 2. Configuration

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
```

Edit `.env` file:

```env
# Server
PORT=3000
NODE_ENV=development

# Security (CHANGE THESE IN PRODUCTION!)
JWT_SECRET=your-super-secret-jwt-key
ENCRYPTION_KEY=your-32-character-encryption-key

# AI Integration (Optional)
HUGGINGFACE_API_TOKEN=your-token-here

# Admin Credentials
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123
```

### 3. Start Server

```bash
# Development mode
npm run dev

# Production mode
npm start
```

The server will start at `http://localhost:3000`

## 📚 API Documentation

### Base URL
```
http://localhost:3000/api/v1
```

### Authentication

#### Register User
```http
POST /api/v1/users/register
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "securepassword",
  "role": "user"
}
```

#### Login
```http
POST /api/v1/users/login
Content-Type: application/json

{
  "username": "john_doe",
  "password": "securepassword"
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": { ... }
}
```

### Protected Endpoints

All protected endpoints require the `Authorization` header:

```http
Authorization: Bearer YOUR_JWT_TOKEN
```

### User Management

```http
GET    /api/v1/users              # Get all users (admin)
GET    /api/v1/users/me           # Get current user
GET    /api/v1/users/:id          # Get user by ID (admin)
PUT    /api/v1/users/me           # Update current user
PUT    /api/v1/users/:id          # Update user (admin)
DELETE /api/v1/users/:id          # Delete user (admin)
```

### App Management

```http
POST   /api/v1/apps/register      # Register new app
GET    /api/v1/apps               # Get all apps
GET    /api/v1/apps/:id           # Get app by ID
PUT    /api/v1/apps/:id           # Update app
DELETE /api/v1/apps/:id           # Delete app
POST   /api/v1/apps/:id/generate-sdk  # Generate SDK
```

### Database Management (Admin Only)

```http
GET    /api/v1/database/collections              # List collections
POST   /api/v1/database/collections              # Create collection
DELETE /api/v1/database/collections/:name        # Drop collection
GET    /api/v1/database/collections/:name/documents  # Get documents
POST   /api/v1/database/collections/:name/documents  # Insert document
GET    /api/v1/database/collections/:name/documents/:id  # Get document
PUT    /api/v1/database/collections/:name/documents/:id  # Update document
DELETE /api/v1/database/collections/:name/documents/:id  # Delete document
POST   /api/v1/database/backup                   # Backup database
POST   /api/v1/database/restore                  # Restore database
GET    /api/v1/database/export                   # Export database
POST   /api/v1/database/import                   # Import database
```

### AI Features (Admin Only)

```http
POST   /api/v1/database/collections/generate     # Generate schema from prompt
POST   /api/v1/ai/generate-app                   # Generate complete app
POST   /api/v1/ai/optimize                       # Get optimization suggestions
POST   /api/v1/ai/security                       # Get security recommendations
```

## 🎨 Admin Panel

Access the admin panel at: `http://localhost:3000/admin`

Default credentials:
- Username: `admin`
- Password: `admin123`

### Admin Panel Features

1. **Dashboard**
   - Server statistics
   - User activity charts
   - API usage graphs
   - Recent activity timeline

2. **User Management**
   - Create/Edit/Delete users
   - Role management
   - Activity monitoring
   - Online status tracking

3. **App Management**
   - Register apps
   - API key management
   - SDK generation
   - Usage statistics

4. **Database Management**
   - Create/Drop collections
   - View/Edit documents
   - Backup/Restore
   - Import/Export

5. **AI Assistant**
   - Generate schemas from prompts
   - Generate complete apps
   - Get optimization suggestions
   - Security recommendations

6. **Realtime Monitor**
   - Active connections
   - Live events
   - Call monitoring

7. **System Logs**
   - Searchable logs
   - Filter by level
   - Export logs

## 🔌 WebSocket/Realtime

### Connect to WebSocket

```javascript
import io from 'socket.io-client';

const socket = io('http://localhost:3000');

// Authenticate
socket.emit('authenticate', {
  token: 'YOUR_JWT_TOKEN'
});

socket.on('auth:success', (data) => {
  console.log('Authenticated:', data);
});

// Listen to database changes
socket.on('db:insert', (data) => {
  console.log('New document:', data);
});

socket.on('db:update', (data) => {
  console.log('Document updated:', data);
});

socket.on('db:delete', (data) => {
  console.log('Document deleted:', data);
});

// Send message
socket.emit('message:send', {
  to: 'user_id',
  message: 'Hello!',
  type: 'text'
});

// Receive message
socket.on('message:received', (data) => {
  console.log('New message:', data);
});
```

## 🤖 AI Integration

### Generate Database Schema

```javascript
const response = await fetch('http://localhost:3000/api/v1/database/collections/generate', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_TOKEN',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    prompt: 'Create a blog system with posts, comments, and tags'
  })
});

const { schema } = await response.json();
console.log(schema);
```

### Generate Complete App

```javascript
const response = await fetch('http://localhost:3000/api/v1/ai/generate-app', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_TOKEN',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    description: 'A task management system with projects, teams, and deadlines'
  })
});

const { appSpec } = await response.json();
console.log(appSpec);
```

## 📁 Project Structure

```
Server/
├── server.js              # Main server file
├── package.json           # Dependencies
├── .env                   # Configuration
├── db/                    # Database module
│   ├── CustomDatabase.js  # Custom DB implementation
│   ├── data/              # JSON storage
│   └── backups/           # Backup files
├── api/                   # API routes
│   ├── users.js           # User management
│   ├── apps.js            # App management
│   └── database.js        # Database management
├── ai/                    # AI integration
│   └── HuggingFaceAI.js   # Hugging Face integration
├── realtime/              # WebSocket/Realtime
│   └── RealtimeEngine.js  # Socket.IO implementation
├── utils/                 # Utilities
│   ├── auth.js            # Authentication
│   └── logger.js          # Logging
├── admin/                 # Admin panel
│   └── public/
│       ├── index.html     # Admin UI
│       └── admin.js       # Admin logic
└── logs/                  # Log files
```

## 🔒 Security Best Practices

1. **Change Default Credentials**
   ```env
   ADMIN_USERNAME=your_admin
   ADMIN_PASSWORD=strong_password_here
   ```

2. **Use Strong JWT Secret**
   ```env
   JWT_SECRET=use-a-long-random-string-here
   ```

3. **Enable Encryption**
   ```env
   ENCRYPTION_KEY=32-character-encryption-key-here
   ```

4. **Enable SSL in Production**
   ```env
   SSL_ENABLED=true
   SSL_KEY_PATH=/path/to/key.pem
   SSL_CERT_PATH=/path/to/cert.pem
   ```

5. **Configure Rate Limiting**
   ```env
   API_RATE_LIMIT=100  # requests per minute
   ```

## 🚀 Deployment

### Wasmer Edge Deployment

This server is compatible with Wasmer Edge. To deploy:

1. Build for WASM target
2. Configure environment variables
3. Deploy to Wasmer Edge

### Traditional Deployment

```bash
# Install dependencies
npm install --production

# Set environment
export NODE_ENV=production

# Start server
npm start
```

### Docker Deployment

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## 📊 Monitoring

### Health Check

```http
GET /health

Response:
{
  "status": "healthy",
  "uptime": 12345,
  "timestamp": "2024-01-01T00:00:00.000Z",
  "version": "1.0.0"
}
```

### Server Info

```http
GET /api/v1/info

Response:
{
  "name": "Universal Node.js Server",
  "version": "1.0.0",
  "features": {
    "database": true,
    "ai": true,
    "realtime": true,
    "multiTenant": true
  }
}
```

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

MIT License - feel free to use this in your projects!

## 🆘 Support

For issues and questions:
- Check the documentation
- Review the code comments
- Open an issue on GitHub

## 🎯 Roadmap

- [ ] GraphQL API support
- [ ] Redis caching layer
- [ ] Kubernetes deployment configs
- [ ] Advanced analytics dashboard
- [ ] Plugin system
- [ ] CLI tool for management
- [ ] Mobile admin app
- [ ] Advanced AI features

## ⚡ Performance Tips

1. **Enable Compression**
   - Already enabled by default

2. **Use Indexes**
   - Define indexes in your schemas for faster queries

3. **Adjust Persistence Interval**
   ```env
   DB_PERSISTENCE_INTERVAL=60000  # milliseconds
   ```

4. **Enable Caching**
   - In-memory caching is enabled by default

5. **Monitor Logs**
   ```env
   LOG_LEVEL=info  # error, warn, info, debug
   ```

---

**Built with ❤️ using Node.js, Express, Socket.IO, and Bootstrap 5**
