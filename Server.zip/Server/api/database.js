import express from 'express';

/**
 * Database Management API Routes
 */
export function createDatabaseRoutes(db, logger, aiEngine) {
    const router = express.Router();

    /**
     * Get all collections
     */
    router.get('/collections', async (req, res) => {
        try {
            const collections = db.getCollections();

            const collectionsInfo = collections.map(name => {
                const schema = db.getSchema(name);
                const count = db.count(name);

                return {
                    name,
                    schema,
                    documentCount: count
                };
            });

            res.json({
                success: true,
                collections: collectionsInfo
            });
        } catch (error) {
            logger?.error('Get collections error', { error: error.message });
            res.status(500).json({ error: 'Failed to get collections' });
        }
    });

    /**
     * Create collection
     */
    router.post('/collections', async (req, res) => {
        try {
            const { name, schema } = req.body;

            if (!name) {
                return res.status(400).json({ error: 'Collection name is required' });
            }

            await db.createCollection(name, schema || {});

            logger?.info('Collection created', { collection: name, userId: req.user.id });

            res.status(201).json({
                success: true,
                message: 'Collection created successfully',
                collection: {
                    name,
                    schema
                }
            });
        } catch (error) {
            logger?.error('Create collection error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * AI-powered schema generation
     */
    router.post('/collections/generate', async (req, res) => {
        try {
            const { prompt } = req.body;

            if (!prompt) {
                return res.status(400).json({ error: 'Prompt is required' });
            }

            if (!aiEngine) {
                return res.status(503).json({ error: 'AI engine not available' });
            }

            const result = await aiEngine.generateSchema(prompt);

            if (!result.success) {
                return res.status(500).json({ error: result.error });
            }

            logger?.info('Schema generated via AI', { prompt, userId: req.user.id });

            res.json({
                success: true,
                schema: result.schema,
                rawResponse: result.rawResponse
            });
        } catch (error) {
            logger?.error('Generate schema error', { error: error.message });
            res.status(500).json({ error: 'Failed to generate schema' });
        }
    });

    /**
     * Apply AI-generated schema
     */
    router.post('/collections/apply-generated', async (req, res) => {
        try {
            const { collectionName, schema } = req.body;

            if (!collectionName || !schema) {
                return res.status(400).json({ error: 'Collection name and schema are required' });
            }

            await db.createCollection(collectionName, schema);

            logger?.info('AI-generated schema applied', { collection: collectionName, userId: req.user.id });

            res.status(201).json({
                success: true,
                message: 'Schema applied successfully',
                collection: {
                    name: collectionName,
                    schema
                }
            });
        } catch (error) {
            logger?.error('Apply schema error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * Drop collection
     */
    router.delete('/collections/:name', async (req, res) => {
        try {
            await db.dropCollection(req.params.name);

            logger?.info('Collection dropped', { collection: req.params.name, userId: req.user.id });

            res.json({
                success: true,
                message: 'Collection dropped successfully'
            });
        } catch (error) {
            logger?.error('Drop collection error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * Get documents from collection
     */
    router.get('/collections/:name/documents', async (req, res) => {
        try {
            const { limit = 50, skip = 0, sort } = req.query;

            const options = {
                limit: parseInt(limit),
                skip: parseInt(skip)
            };

            if (sort) {
                try {
                    options.sort = JSON.parse(sort);
                } catch (e) {
                    return res.status(400).json({ error: 'Invalid sort parameter' });
                }
            }

            const documents = await db.find(req.params.name, {}, options);
            const total = await db.count(req.params.name);

            res.json({
                success: true,
                documents,
                total,
                limit: options.limit,
                skip: options.skip
            });
        } catch (error) {
            logger?.error('Get documents error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * Query documents
     */
    router.post('/collections/:name/query', async (req, res) => {
        try {
            const { query, options } = req.body;

            const documents = await db.find(req.params.name, query || {}, options || {});

            res.json({
                success: true,
                documents,
                count: documents.length
            });
        } catch (error) {
            logger?.error('Query documents error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * Insert document
     */
    router.post('/collections/:name/documents', async (req, res) => {
        try {
            const document = await db.insert(req.params.name, req.body);

            logger?.info('Document inserted', { collection: req.params.name, documentId: document._id });

            res.status(201).json({
                success: true,
                document
            });
        } catch (error) {
            logger?.error('Insert document error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * Get document by ID
     */
    router.get('/collections/:name/documents/:id', async (req, res) => {
        try {
            const document = await db.findById(req.params.name, req.params.id);

            if (!document) {
                return res.status(404).json({ error: 'Document not found' });
            }

            res.json({
                success: true,
                document
            });
        } catch (error) {
            logger?.error('Get document error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * Update document
     */
    router.put('/collections/:name/documents/:id', async (req, res) => {
        try {
            const result = await db.update(
                req.params.name,
                { _id: req.params.id },
                req.body,
                { updateOne: true }
            );

            if (result.matched === 0) {
                return res.status(404).json({ error: 'Document not found' });
            }

            const document = await db.findById(req.params.name, req.params.id);

            logger?.info('Document updated', { collection: req.params.name, documentId: req.params.id });

            res.json({
                success: true,
                document
            });
        } catch (error) {
            logger?.error('Update document error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * Delete document
     */
    router.delete('/collections/:name/documents/:id', async (req, res) => {
        try {
            const result = await db.delete(
                req.params.name,
                { _id: req.params.id },
                { deleteOne: true }
            );

            if (result.deleted === 0) {
                return res.status(404).json({ error: 'Document not found' });
            }

            logger?.info('Document deleted', { collection: req.params.name, documentId: req.params.id });

            res.json({
                success: true,
                message: 'Document deleted successfully'
            });
        } catch (error) {
            logger?.error('Delete document error', { error: error.message });
            res.status(500).json({ error: error.message });
        }
    });

    /**
     * Backup database
     */
    router.post('/backup', async (req, res) => {
        try {
            const { name } = req.body;

            const backupPath = await db.backup(name);

            logger?.info('Database backup created', { backupPath, userId: req.user.id });

            res.json({
                success: true,
                message: 'Backup created successfully',
                backupPath
            });
        } catch (error) {
            logger?.error('Backup error', { error: error.message });
            res.status(500).json({ error: 'Failed to create backup' });
        }
    });

    /**
     * Restore database
     */
    router.post('/restore', async (req, res) => {
        try {
            const { backupPath } = req.body;

            if (!backupPath) {
                return res.status(400).json({ error: 'Backup path is required' });
            }

            await db.restore(backupPath);

            logger?.info('Database restored', { backupPath, userId: req.user.id });

            res.json({
                success: true,
                message: 'Database restored successfully'
            });
        } catch (error) {
            logger?.error('Restore error', { error: error.message });
            res.status(500).json({ error: 'Failed to restore database' });
        }
    });

    /**
     * Export database
     */
    router.get('/export', async (req, res) => {
        try {
            const data = db.exportData();

            logger?.info('Database exported', { userId: req.user.id });

            res.json({
                success: true,
                data
            });
        } catch (error) {
            logger?.error('Export error', { error: error.message });
            res.status(500).json({ error: 'Failed to export database' });
        }
    });

    /**
     * Import database
     */
    router.post('/import', async (req, res) => {
        try {
            const { data } = req.body;

            if (!data) {
                return res.status(400).json({ error: 'Data is required' });
            }

            db.importData(data);
            await db.persistToDisk();

            logger?.info('Database imported', { userId: req.user.id });

            res.json({
                success: true,
                message: 'Database imported successfully'
            });
        } catch (error) {
            logger?.error('Import error', { error: error.message });
            res.status(500).json({ error: 'Failed to import database' });
        }
    });

    /**
     * Get database statistics
     */
    router.get('/stats', async (req, res) => {
        try {
            const collections = db.getCollections();

            const stats = {
                totalCollections: collections.length,
                collections: collections.map(name => ({
                    name,
                    documentCount: db.count(name),
                    schema: db.getSchema(name)
                })),
                metadata: db.metadata
            };

            res.json({
                success: true,
                stats
            });
        } catch (error) {
            logger?.error('Get stats error', { error: error.message });
            res.status(500).json({ error: 'Failed to get statistics' });
        }
    });

    return router;
}

export default createDatabaseRoutes;
