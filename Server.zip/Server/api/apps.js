import express from 'express';

/**
 * App Management API Routes
 */
export function createAppRoutes(db, authUtils, logger, aiEngine) {
    const router = express.Router();

    /**
     * Register new app
     */
    router.post('/register', async (req, res) => {
        try {
            const { name, description, webhookUrl } = req.body;

            if (!name) {
                return res.status(400).json({ error: 'App name is required' });
            }

            // Check if app exists
            const existing = await db.findOne('apps', { name });
            if (existing) {
                return res.status(409).json({ error: 'App already exists' });
            }

            // Generate API key
            const apiKey = authUtils.generateApiKey('app');

            // Create app
            const app = await db.insert('apps', {
                name,
                description: description || '',
                apiKey,
                webhookUrl: webhookUrl || '',
                active: true,
                ownerId: req.user.id,
                createdAt: new Date().toISOString(),
                settings: {},
                stats: {
                    apiCalls: 0,
                    lastApiCall: null,
                    errors: 0
                }
            });

            logger?.info('App registered', { appId: app._id, name, ownerId: req.user.id });

            res.status(201).json({
                success: true,
                app: {
                    id: app._id,
                    name: app.name,
                    description: app.description,
                    apiKey: app.apiKey,
                    active: app.active,
                    createdAt: app.createdAt
                }
            });
        } catch (error) {
            logger?.error('App registration error', { error: error.message });
            res.status(500).json({ error: 'Failed to register app' });
        }
    });

    /**
     * Get all apps
     */
    router.get('/', async (req, res) => {
        try {
            const { active, search, limit = 50, skip = 0 } = req.query;

            const query = {};

            // Non-admin users can only see their own apps
            if (req.user.role !== 'admin') {
                query.ownerId = req.user.id;
            }

            if (active !== undefined) {
                query.active = active === 'true';
            }

            let apps = await db.find('apps', query, {
                limit: parseInt(limit),
                skip: parseInt(skip)
            });

            if (search) {
                apps = apps.filter(a =>
                    a.name.toLowerCase().includes(search.toLowerCase()) ||
                    a.description.toLowerCase().includes(search.toLowerCase())
                );
            }

            const total = await db.count('apps', query);

            res.json({
                success: true,
                apps: apps.map(a => ({
                    id: a._id,
                    name: a.name,
                    description: a.description,
                    active: a.active,
                    createdAt: a.createdAt,
                    stats: a.stats
                })),
                total
            });
        } catch (error) {
            logger?.error('Get apps error', { error: error.message });
            res.status(500).json({ error: 'Failed to get apps' });
        }
    });

    /**
     * Get app by ID
     */
    router.get('/:id', async (req, res) => {
        try {
            const app = await db.findById('apps', req.params.id);
            if (!app) {
                return res.status(404).json({ error: 'App not found' });
            }

            // Check ownership
            if (req.user.role !== 'admin' && app.ownerId !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            res.json({
                success: true,
                app: {
                    id: app._id,
                    name: app.name,
                    description: app.description,
                    apiKey: app.apiKey,
                    webhookUrl: app.webhookUrl,
                    active: app.active,
                    ownerId: app.ownerId,
                    createdAt: app.createdAt,
                    settings: app.settings,
                    stats: app.stats
                }
            });
        } catch (error) {
            logger?.error('Get app error', { error: error.message });
            res.status(500).json({ error: 'Failed to get app' });
        }
    });

    /**
     * Update app
     */
    router.put('/:id', async (req, res) => {
        try {
            const app = await db.findById('apps', req.params.id);
            if (!app) {
                return res.status(404).json({ error: 'App not found' });
            }

            // Check ownership
            if (req.user.role !== 'admin' && app.ownerId !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            const { name, description, webhookUrl, active, settings } = req.body;
            const updates = {};

            if (name) updates.name = name;
            if (description !== undefined) updates.description = description;
            if (webhookUrl !== undefined) updates.webhookUrl = webhookUrl;
            if (active !== undefined) updates.active = active;
            if (settings) updates.settings = { ...app.settings, ...settings };

            await db.update('apps', { _id: req.params.id }, updates, { updateOne: true });

            const updatedApp = await db.findById('apps', req.params.id);

            logger?.info('App updated', { appId: updatedApp._id, userId: req.user.id });

            res.json({
                success: true,
                app: {
                    id: updatedApp._id,
                    name: updatedApp.name,
                    description: updatedApp.description,
                    active: updatedApp.active,
                    settings: updatedApp.settings
                }
            });
        } catch (error) {
            logger?.error('Update app error', { error: error.message });
            res.status(500).json({ error: 'Failed to update app' });
        }
    });

    /**
     * Regenerate API key
     */
    router.post('/:id/regenerate-key', async (req, res) => {
        try {
            const app = await db.findById('apps', req.params.id);
            if (!app) {
                return res.status(404).json({ error: 'App not found' });
            }

            // Check ownership
            if (req.user.role !== 'admin' && app.ownerId !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            const newApiKey = authUtils.generateApiKey('app');

            await db.update('apps', { _id: req.params.id }, {
                apiKey: newApiKey
            }, { updateOne: true });

            logger?.info('API key regenerated', { appId: app._id, userId: req.user.id });

            res.json({
                success: true,
                apiKey: newApiKey
            });
        } catch (error) {
            logger?.error('Regenerate key error', { error: error.message });
            res.status(500).json({ error: 'Failed to regenerate API key' });
        }
    });

    /**
     * Delete app
     */
    router.delete('/:id', async (req, res) => {
        try {
            const app = await db.findById('apps', req.params.id);
            if (!app) {
                return res.status(404).json({ error: 'App not found' });
            }

            // Check ownership
            if (req.user.role !== 'admin' && app.ownerId !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            await db.delete('apps', { _id: req.params.id }, { deleteOne: true });

            logger?.info('App deleted', { appId: req.params.id, userId: req.user.id });

            res.json({ success: true, message: 'App deleted successfully' });
        } catch (error) {
            logger?.error('Delete app error', { error: error.message });
            res.status(500).json({ error: 'Failed to delete app' });
        }
    });

    /**
     * Get app statistics
     */
    router.get('/:id/stats', async (req, res) => {
        try {
            const app = await db.findById('apps', req.params.id);
            if (!app) {
                return res.status(404).json({ error: 'App not found' });
            }

            // Check ownership
            if (req.user.role !== 'admin' && app.ownerId !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            res.json({
                success: true,
                stats: app.stats
            });
        } catch (error) {
            logger?.error('Get stats error', { error: error.message });
            res.status(500).json({ error: 'Failed to get statistics' });
        }
    });

    /**
     * Generate SDK for app
     */
    router.post('/:id/generate-sdk', async (req, res) => {
        try {
            const app = await db.findById('apps', req.params.id);
            if (!app) {
                return res.status(404).json({ error: 'App not found' });
            }

            // Check ownership
            if (req.user.role !== 'admin' && app.ownerId !== req.user.id) {
                return res.status(403).json({ error: 'Access denied' });
            }

            const { baseUrl } = req.body;

            if (!baseUrl) {
                return res.status(400).json({ error: 'Base URL is required' });
            }

            // Get all available endpoints
            const endpoints = [
                { name: 'getUsers', method: 'GET', path: '/api/v1/users' },
                { name: 'createUser', method: 'POST', path: '/api/v1/users/register' },
                { name: 'getApps', method: 'GET', path: '/api/v1/apps' },
                { name: 'getDatabaseCollections', method: 'GET', path: '/api/v1/database/collections' }
            ];

            // Generate SDK using AI if available
            let sdk;
            if (aiEngine) {
                const result = await aiEngine.generateSDK(app.name, baseUrl, app.apiKey, endpoints);
                if (result.success) {
                    sdk = result.sdk;
                }
            }

            // Fallback to manual SDK generation
            if (!sdk) {
                sdk = {
                    appName: app.name,
                    version: '1.0.0',
                    baseUrl,
                    auth: {
                        type: 'apiKey',
                        apiKey: app.apiKey
                    },
                    endpoints: endpoints.reduce((acc, ep) => {
                        acc[ep.name] = {
                            method: ep.method,
                            path: ep.path,
                            description: `${ep.method} ${ep.path}`
                        };
                        return acc;
                    }, {}),
                    websocket: {
                        enabled: true,
                        url: baseUrl.replace('http', 'ws'),
                        events: ['db:insert', 'db:update', 'db:delete', 'message:received', 'call:incoming']
                    }
                };
            }

            logger?.info('SDK generated', { appId: app._id, userId: req.user.id });

            res.json({
                success: true,
                sdk
            });
        } catch (error) {
            logger?.error('Generate SDK error', { error: error.message });
            res.status(500).json({ error: 'Failed to generate SDK' });
        }
    });

    return router;
}

export default createAppRoutes;
