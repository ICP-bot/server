import express from 'express';

/**
 * User Management API Routes
 */
export function createUserRoutes(db, authUtils, logger) {
    const router = express.Router();

    /**
     * Register new user
     */
    router.post('/register', async (req, res) => {
        try {
            const { username, email, password, role } = req.body;

            // Validation
            if (!username || !email || !password) {
                return res.status(400).json({ error: 'Missing required fields' });
            }

            // Check if user exists
            const existing = await db.findOne('users', { $or: [{ username }, { email }] });
            if (existing) {
                return res.status(409).json({ error: 'User already exists' });
            }

            // Hash password
            const hashedPassword = await authUtils.hashPassword(password);

            // Create user
            const user = await db.insert('users', {
                username,
                email,
                password: hashedPassword,
                role: role || 'user',
                active: true,
                online: false,
                status: 'offline',
                customStatus: '',
                createdAt: new Date().toISOString(),
                lastSeen: new Date().toISOString()
            });

            // Generate token
            const token = authUtils.generateToken({
                id: user._id,
                username: user.username,
                role: user.role
            });

            logger?.info('User registered', { userId: user._id, username });

            res.status(201).json({
                success: true,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role
                },
                token
            });
        } catch (error) {
            logger?.error('Registration error', { error: error.message });
            res.status(500).json({ error: 'Registration failed' });
        }
    });

    /**
     * Login user
     */
    router.post('/login', async (req, res) => {
        try {
            const { username, password } = req.body;

            if (!username || !password) {
                return res.status(400).json({ error: 'Missing credentials' });
            }

            // Find user
            const user = await db.findOne('users', { username });
            if (!user) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }

            // Check password
            const validPassword = await authUtils.comparePassword(password, user.password);
            if (!validPassword) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }

            if (!user.active) {
                return res.status(403).json({ error: 'Account is disabled' });
            }

            // Generate token
            const token = authUtils.generateToken({
                id: user._id,
                username: user.username,
                role: user.role
            });

            // Update last login
            await db.update('users', { _id: user._id }, {
                lastLogin: new Date().toISOString()
            }, { updateOne: true });

            logger?.info('User logged in', { userId: user._id, username });

            res.json({
                success: true,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role
                },
                token
            });
        } catch (error) {
            logger?.error('Login error', { error: error.message });
            res.status(500).json({ error: 'Login failed' });
        }
    });

    /**
     * Get current user
     */
    router.get('/me', async (req, res) => {
        try {
            const user = await db.findById('users', req.user.id);
            if (!user) {
                return res.status(404).json({ error: 'User not found' });
            }

            res.json({
                success: true,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    status: user.status,
                    customStatus: user.customStatus,
                    online: user.online,
                    lastSeen: user.lastSeen
                }
            });
        } catch (error) {
            logger?.error('Get user error', { error: error.message });
            res.status(500).json({ error: 'Failed to get user' });
        }
    });

    /**
     * Update user
     */
    router.put('/me', async (req, res) => {
        try {
            const { email, customStatus } = req.body;
            const updates = {};

            if (email) updates.email = email;
            if (customStatus !== undefined) updates.customStatus = customStatus;

            await db.update('users', { _id: req.user.id }, updates, { updateOne: true });

            const user = await db.findById('users', req.user.id);

            logger?.info('User updated', { userId: user._id });

            res.json({
                success: true,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    customStatus: user.customStatus
                }
            });
        } catch (error) {
            logger?.error('Update user error', { error: error.message });
            res.status(500).json({ error: 'Failed to update user' });
        }
    });

    /**
     * Change password
     */
    router.put('/me/password', async (req, res) => {
        try {
            const { currentPassword, newPassword } = req.body;

            if (!currentPassword || !newPassword) {
                return res.status(400).json({ error: 'Missing passwords' });
            }

            const user = await db.findById('users', req.user.id);

            // Verify current password
            const validPassword = await authUtils.comparePassword(currentPassword, user.password);
            if (!validPassword) {
                return res.status(401).json({ error: 'Invalid current password' });
            }

            // Hash new password
            const hashedPassword = await authUtils.hashPassword(newPassword);

            await db.update('users', { _id: req.user.id }, {
                password: hashedPassword
            }, { updateOne: true });

            logger?.info('Password changed', { userId: user._id });

            res.json({ success: true, message: 'Password changed successfully' });
        } catch (error) {
            logger?.error('Change password error', { error: error.message });
            res.status(500).json({ error: 'Failed to change password' });
        }
    });

    /**
     * Get all users (admin only)
     */
    router.get('/', async (req, res) => {
        try {
            const { role, status, search, limit = 50, skip = 0 } = req.query;

            const query = {};
            if (role) query.role = role;
            if (status) query.status = status;
            if (search) {
                // Simple search implementation
                const users = await db.find('users', {});
                const filtered = users.filter(u =>
                    u.username.toLowerCase().includes(search.toLowerCase()) ||
                    u.email.toLowerCase().includes(search.toLowerCase())
                );

                return res.json({
                    success: true,
                    users: filtered.slice(skip, skip + parseInt(limit)).map(u => ({
                        id: u._id,
                        username: u.username,
                        email: u.email,
                        role: u.role,
                        active: u.active,
                        online: u.online,
                        lastSeen: u.lastSeen
                    })),
                    total: filtered.length
                });
            }

            const users = await db.find('users', query, {
                limit: parseInt(limit),
                skip: parseInt(skip)
            });

            const total = await db.count('users', query);

            res.json({
                success: true,
                users: users.map(u => ({
                    id: u._id,
                    username: u.username,
                    email: u.email,
                    role: u.role,
                    active: u.active,
                    online: u.online,
                    lastSeen: u.lastSeen
                })),
                total
            });
        } catch (error) {
            logger?.error('Get users error', { error: error.message });
            res.status(500).json({ error: 'Failed to get users' });
        }
    });

    /**
     * Get user by ID (admin only)
     */
    router.get('/:id', async (req, res) => {
        try {
            const user = await db.findById('users', req.params.id);
            if (!user) {
                return res.status(404).json({ error: 'User not found' });
            }

            res.json({
                success: true,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    active: user.active,
                    online: user.online,
                    status: user.status,
                    customStatus: user.customStatus,
                    lastSeen: user.lastSeen,
                    createdAt: user.createdAt,
                    lastLogin: user.lastLogin
                }
            });
        } catch (error) {
            logger?.error('Get user error', { error: error.message });
            res.status(500).json({ error: 'Failed to get user' });
        }
    });

    /**
     * Update user (admin only)
     */
    router.put('/:id', async (req, res) => {
        try {
            const { role, active } = req.body;
            const updates = {};

            if (role) updates.role = role;
            if (active !== undefined) updates.active = active;

            await db.update('users', { _id: req.params.id }, updates, { updateOne: true });

            const user = await db.findById('users', req.params.id);

            logger?.info('User updated by admin', { userId: user._id, adminId: req.user.id });

            res.json({
                success: true,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    active: user.active
                }
            });
        } catch (error) {
            logger?.error('Update user error', { error: error.message });
            res.status(500).json({ error: 'Failed to update user' });
        }
    });

    /**
     * Delete user (admin only)
     */
    router.delete('/:id', async (req, res) => {
        try {
            await db.delete('users', { _id: req.params.id }, { deleteOne: true });

            logger?.info('User deleted', { userId: req.params.id, adminId: req.user.id });

            res.json({ success: true, message: 'User deleted successfully' });
        } catch (error) {
            logger?.error('Delete user error', { error: error.message });
            res.status(500).json({ error: 'Failed to delete user' });
        }
    });

    /**
     * Get user activity
     */
    router.get('/:id/activity', async (req, res) => {
        try {
            const { limit = 50 } = req.query;

            // Get user's recent activity from logs
            const logs = await logger?.getLogs({
                search: req.params.id,
                limit: parseInt(limit)
            }) || [];

            res.json({
                success: true,
                activity: logs
            });
        } catch (error) {
            logger?.error('Get activity error', { error: error.message });
            res.status(500).json({ error: 'Failed to get activity' });
        }
    });

    return router;
}

export default createUserRoutes;
