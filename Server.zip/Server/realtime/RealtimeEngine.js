import { Server } from 'socket.io';

/**
 * Realtime Engine using Socket.IO
 * Handles WebSocket connections, events, and realtime database sync
 */
class RealtimeEngine {
    constructor(httpServer, options = {}) {
        this.io = new Server(httpServer, {
            cors: {
                origin: options.corsOrigin || '*',
                methods: ['GET', 'POST']
            },
            pingInterval: options.pingInterval || 25000,
            pingTimeout: options.pingTimeout || 60000
        });

        this.db = options.db;
        this.authUtils = options.authUtils;
        this.logger = options.logger;

        // Connection tracking
        this.connections = new Map();
        this.userSockets = new Map();
        this.appSockets = new Map();

        this.setupEventHandlers();
    }

    /**
     * Setup Socket.IO event handlers
     */
    setupEventHandlers() {
        this.io.on('connection', (socket) => {
            this.handleConnection(socket);
        });

        // Listen to database events for realtime sync
        if (this.db) {
            this.db.on('document:inserted', (data) => {
                this.broadcast('db:insert', data);
            });

            this.db.on('document:updated', (data) => {
                this.broadcast('db:update', data);
            });

            this.db.on('document:deleted', (data) => {
                this.broadcast('db:delete', data);
            });
        }
    }

    /**
     * Handle new socket connection
     */
    handleConnection(socket) {
        this.logger?.info('New socket connection', { socketId: socket.id });

        // Store connection
        this.connections.set(socket.id, {
            socket,
            connectedAt: new Date(),
            authenticated: false
        });

        // Authentication
        socket.on('authenticate', async (data) => {
            await this.handleAuthentication(socket, data);
        });

        // Presence
        socket.on('presence:update', (data) => {
            this.handlePresenceUpdate(socket, data);
        });

        // Chat/Messaging
        socket.on('message:send', (data) => {
            this.handleMessage(socket, data);
        });

        socket.on('message:typing', (data) => {
            this.handleTyping(socket, data);
        });

        // Calls
        socket.on('call:initiate', (data) => {
            this.handleCallInitiate(socket, data);
        });

        socket.on('call:answer', (data) => {
            this.handleCallAnswer(socket, data);
        });

        socket.on('call:end', (data) => {
            this.handleCallEnd(socket, data);
        });

        socket.on('call:signal', (data) => {
            this.handleCallSignal(socket, data);
        });

        // Custom events
        socket.on('custom:event', (data) => {
            this.handleCustomEvent(socket, data);
        });

        // Room management
        socket.on('room:join', (data) => {
            this.handleRoomJoin(socket, data);
        });

        socket.on('room:leave', (data) => {
            this.handleRoomLeave(socket, data);
        });

        // Disconnect
        socket.on('disconnect', () => {
            this.handleDisconnect(socket);
        });
    }

    /**
     * Handle authentication
     */
    async handleAuthentication(socket, data) {
        try {
            const { token, apiKey, userId } = data;

            let user = null;
            let app = null;

            // JWT authentication
            if (token && this.authUtils) {
                try {
                    const decoded = this.authUtils.verifyToken(token);
                    user = await this.db.findById('users', decoded.id);
                } catch (error) {
                    socket.emit('auth:error', { message: 'Invalid token' });
                    return;
                }
            }

            // API key authentication
            if (apiKey && this.db) {
                const apps = await this.db.find('apps', { apiKey });
                app = apps[0];
            }

            if (!user && !app && userId) {
                user = await this.db.findById('users', userId);
            }

            if (user || app) {
                const connection = this.connections.get(socket.id);
                connection.authenticated = true;
                connection.user = user;
                connection.app = app;

                // Track user sockets
                if (user) {
                    if (!this.userSockets.has(user._id)) {
                        this.userSockets.set(user._id, new Set());
                    }
                    this.userSockets.get(user._id).add(socket.id);

                    // Update user presence
                    await this.db.update('users', { _id: user._id }, {
                        online: true,
                        lastSeen: new Date().toISOString()
                    }, { updateOne: true });
                }

                // Track app sockets
                if (app) {
                    if (!this.appSockets.has(app._id)) {
                        this.appSockets.set(app._id, new Set());
                    }
                    this.appSockets.get(app._id).add(socket.id);
                }

                socket.emit('auth:success', {
                    user: user ? { id: user._id, username: user.username, role: user.role } : null,
                    app: app ? { id: app._id, name: app.name } : null
                });

                this.logger?.info('Socket authenticated', {
                    socketId: socket.id,
                    userId: user?._id,
                    appId: app?._id
                });
            } else {
                socket.emit('auth:error', { message: 'Authentication failed' });
            }
        } catch (error) {
            this.logger?.error('Authentication error', { error: error.message });
            socket.emit('auth:error', { message: 'Authentication failed' });
        }
    }

    /**
     * Handle presence update
     */
    async handlePresenceUpdate(socket, data) {
        const connection = this.connections.get(socket.id);
        if (!connection?.authenticated || !connection.user) return;

        const { status, customStatus } = data;

        await this.db.update('users', { _id: connection.user._id }, {
            status: status || 'online',
            customStatus: customStatus || '',
            lastSeen: new Date().toISOString()
        }, { updateOne: true });

        // Broadcast to user's contacts
        this.broadcastToUser(connection.user._id, 'presence:updated', {
            userId: connection.user._id,
            status,
            customStatus
        });
    }

    /**
     * Handle message
     */
    async handleMessage(socket, data) {
        const connection = this.connections.get(socket.id);
        if (!connection?.authenticated) return;

        const { to, message, type, metadata } = data;

        // Save message to database
        const msg = await this.db.insert('messages', {
            from: connection.user?._id || connection.app?._id,
            to,
            message,
            type: type || 'text',
            metadata: metadata || {},
            read: false,
            timestamp: new Date().toISOString()
        });

        // Send to recipient
        this.sendToUser(to, 'message:received', msg);

        // Confirm to sender
        socket.emit('message:sent', { messageId: msg._id });

        this.logger?.info('Message sent', { from: msg.from, to: msg.to });
    }

    /**
     * Handle typing indicator
     */
    handleTyping(socket, data) {
        const connection = this.connections.get(socket.id);
        if (!connection?.authenticated || !connection.user) return;

        const { to, typing } = data;

        this.sendToUser(to, 'message:typing', {
            from: connection.user._id,
            typing
        });
    }

    /**
     * Handle call initiation
     */
    async handleCallInitiate(socket, data) {
        const connection = this.connections.get(socket.id);
        if (!connection?.authenticated || !connection.user) return;

        const { to, type, metadata } = data;

        // Create call record
        const call = await this.db.insert('calls', {
            from: connection.user._id,
            to,
            type: type || 'audio',
            status: 'ringing',
            metadata: metadata || {},
            startedAt: new Date().toISOString()
        });

        // Send to recipient
        this.sendToUser(to, 'call:incoming', {
            callId: call._id,
            from: connection.user._id,
            type,
            metadata
        });

        socket.emit('call:initiated', { callId: call._id });

        this.logger?.info('Call initiated', { callId: call._id, from: call.from, to: call.to });
    }

    /**
     * Handle call answer
     */
    async handleCallAnswer(socket, data) {
        const connection = this.connections.get(socket.id);
        if (!connection?.authenticated || !connection.user) return;

        const { callId, accept } = data;

        const call = await this.db.findById('calls', callId);
        if (!call) return;

        if (accept) {
            await this.db.update('calls', { _id: callId }, {
                status: 'active',
                answeredAt: new Date().toISOString()
            }, { updateOne: true });

            // Notify caller
            this.sendToUser(call.from, 'call:answered', { callId });
        } else {
            await this.db.update('calls', { _id: callId }, {
                status: 'rejected',
                endedAt: new Date().toISOString()
            }, { updateOne: true });

            // Notify caller
            this.sendToUser(call.from, 'call:rejected', { callId });
        }
    }

    /**
     * Handle call end
     */
    async handleCallEnd(socket, data) {
        const { callId } = data;

        await this.db.update('calls', { _id: callId }, {
            status: 'ended',
            endedAt: new Date().toISOString()
        }, { updateOne: true });

        const call = await this.db.findById('calls', callId);
        if (call) {
            this.sendToUser(call.from, 'call:ended', { callId });
            this.sendToUser(call.to, 'call:ended', { callId });
        }

        this.logger?.info('Call ended', { callId });
    }

    /**
     * Handle WebRTC signaling
     */
    handleCallSignal(socket, data) {
        const { to, signal } = data;
        this.sendToUser(to, 'call:signal', signal);
    }

    /**
     * Handle custom event
     */
    handleCustomEvent(socket, data) {
        const connection = this.connections.get(socket.id);
        if (!connection?.authenticated) return;

        const { event, payload, to } = data;

        if (to) {
            this.sendToUser(to, event, payload);
        } else {
            this.broadcast(event, payload);
        }
    }

    /**
     * Handle room join
     */
    handleRoomJoin(socket, data) {
        const { room } = data;
        socket.join(room);
        socket.emit('room:joined', { room });
        this.logger?.info('Socket joined room', { socketId: socket.id, room });
    }

    /**
     * Handle room leave
     */
    handleRoomLeave(socket, data) {
        const { room } = data;
        socket.leave(room);
        socket.emit('room:left', { room });
        this.logger?.info('Socket left room', { socketId: socket.id, room });
    }

    /**
     * Handle disconnect
     */
    async handleDisconnect(socket) {
        const connection = this.connections.get(socket.id);

        if (connection?.user) {
            const userSockets = this.userSockets.get(connection.user._id);
            if (userSockets) {
                userSockets.delete(socket.id);

                // If no more sockets for this user, mark as offline
                if (userSockets.size === 0) {
                    await this.db.update('users', { _id: connection.user._id }, {
                        online: false,
                        lastSeen: new Date().toISOString()
                    }, { updateOne: true });

                    this.userSockets.delete(connection.user._id);
                }
            }
        }

        if (connection?.app) {
            const appSockets = this.appSockets.get(connection.app._id);
            if (appSockets) {
                appSockets.delete(socket.id);
                if (appSockets.size === 0) {
                    this.appSockets.delete(connection.app._id);
                }
            }
        }

        this.connections.delete(socket.id);
        this.logger?.info('Socket disconnected', { socketId: socket.id });
    }

    /**
     * Send event to specific user
     */
    sendToUser(userId, event, data) {
        const sockets = this.userSockets.get(userId);
        if (sockets) {
            for (const socketId of sockets) {
                const connection = this.connections.get(socketId);
                if (connection) {
                    connection.socket.emit(event, data);
                }
            }
        }
    }

    /**
     * Broadcast to user (excluding sender)
     */
    broadcastToUser(userId, event, data) {
        const sockets = this.userSockets.get(userId);
        if (sockets) {
            for (const socketId of sockets) {
                const connection = this.connections.get(socketId);
                if (connection) {
                    connection.socket.broadcast.emit(event, data);
                }
            }
        }
    }

    /**
     * Broadcast to all connected clients
     */
    broadcast(event, data) {
        this.io.emit(event, data);
    }

    /**
     * Broadcast to room
     */
    broadcastToRoom(room, event, data) {
        this.io.to(room).emit(event, data);
    }

    /**
     * Get connection stats
     */
    getStats() {
        return {
            totalConnections: this.connections.size,
            authenticatedConnections: Array.from(this.connections.values()).filter(c => c.authenticated).length,
            uniqueUsers: this.userSockets.size,
            uniqueApps: this.appSockets.size
        };
    }

    /**
     * Get active users
     */
    getActiveUsers() {
        return Array.from(this.userSockets.keys());
    }

    /**
     * Disconnect user
     */
    disconnectUser(userId) {
        const sockets = this.userSockets.get(userId);
        if (sockets) {
            for (const socketId of sockets) {
                const connection = this.connections.get(socketId);
                if (connection) {
                    connection.socket.disconnect(true);
                }
            }
        }
    }
}

export default RealtimeEngine;
