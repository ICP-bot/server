import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import path from 'path';
import { fileURLToPath } from 'url';

// Import custom modules
import CustomDatabase from './db/CustomDatabase.js';
import HuggingFaceAI from './ai/HuggingFaceAI.js';
import AuthUtils, { authenticateJWT, requireRole } from './utils/auth.js';
import Logger from './utils/logger.js';
import RealtimeEngine from './realtime/RealtimeEngine.js';

// Import API routes
import { createUserRoutes } from './api/users.js';
import { createAppRoutes } from './api/apps.js';
import { createDatabaseRoutes } from './api/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Universal Node.js Server
 * Multi-tenant server with custom database, AI integration, and realtime features
 */
class UniversalServer {
    constructor() {
        this.app = express();
        this.httpServer = createServer(this.app);
        this.port = process.env.PORT || 3000;
        this.host = process.env.HOST || '0.0.0.0';

        // Initialize components
        this.db = null;
        this.aiEngine = null;
        this.authUtils = null;
        this.logger = null;
        this.realtimeEngine = null;
    }

    /**
     * Initialize all server components
     */
    async initialize() {
        console.log('🚀 Initializing Universal Node.js Server...\n');

        // Initialize logger
        this.logger = new Logger({
            level: process.env.LOG_LEVEL || 'info',
            fileEnabled: process.env.LOG_FILE_ENABLED === 'true',
            filePath: process.env.LOG_FILE_PATH || './logs/server.log'
        });
        await this.logger.initialize();
        this.logger.info('Logger initialized');

        // Initialize database
        this.db = new CustomDatabase({
            storageType: process.env.DB_STORAGE_TYPE || 'json',
            dataDir: './db/data',
            backupDir: './db/backups',
            encryptionKey: process.env.ENCRYPTION_KEY,
            persistenceInterval: parseInt(process.env.DB_PERSISTENCE_INTERVAL) || 60000
        });
        await this.db.initialize();
        this.logger.info('Database initialized');

        // Initialize default collections
        await this.initializeDefaultCollections();

        // Initialize authentication utilities
        this.authUtils = new AuthUtils(
            process.env.JWT_SECRET || 'default-secret-key',
            process.env.JWT_EXPIRES_IN || '24h'
        );
        this.logger.info('Authentication utilities initialized');

        // Initialize AI engine (optional)
        if (process.env.HF_TOKEN) {
            this.aiEngine = new HuggingFaceAI(
                process.env.HF_TOKEN,
                process.env.AI_MODEL || 'openai/gpt-oss-120b:groq',
                process.env.AI_BASE_URL || 'https://router.huggingface.co/v1'
            );
            this.logger.info('AI engine initialized with GPT-OSS-120B');
        } else {
            this.logger.warn('AI engine not initialized (no HF_TOKEN provided)');
        }

        // Setup Express middleware
        this.setupMiddleware();

        // Setup routes
        this.setupRoutes();

        // Initialize realtime engine
        if (process.env.WS_ENABLED === 'true') {
            this.realtimeEngine = new RealtimeEngine(this.httpServer, {
                db: this.db,
                authUtils: this.authUtils,
                logger: this.logger,
                pingInterval: parseInt(process.env.WS_PING_INTERVAL) || 25000,
                pingTimeout: parseInt(process.env.WS_PING_TIMEOUT) || 60000
            });
            this.logger.info('Realtime engine initialized');
        }

        // Create default admin user
        await this.createDefaultAdmin();

        this.logger.info('Server initialization complete');
    }

    /**
     * Initialize default database collections
     */
    async initializeDefaultCollections() {
        const collections = [
            {
                name: 'users',
                schema: {
                    fields: {
                        username: { type: 'string', required: true },
                        email: { type: 'string', required: true },
                        password: { type: 'string', required: true },
                        role: { type: 'string', required: true },
                        active: { type: 'boolean', required: true },
                        online: { type: 'boolean', required: false },
                        status: { type: 'string', required: false },
                        customStatus: { type: 'string', required: false }
                    },
                    indexes: ['username', 'email', 'role']
                }
            },
            {
                name: 'apps',
                schema: {
                    fields: {
                        name: { type: 'string', required: true },
                        description: { type: 'string', required: false },
                        apiKey: { type: 'string', required: true },
                        active: { type: 'boolean', required: true },
                        ownerId: { type: 'string', required: true }
                    },
                    indexes: ['name', 'apiKey', 'ownerId']
                }
            },
            {
                name: 'messages',
                schema: {
                    fields: {
                        from: { type: 'string', required: true },
                        to: { type: 'string', required: true },
                        message: { type: 'string', required: true },
                        type: { type: 'string', required: false },
                        read: { type: 'boolean', required: false }
                    },
                    indexes: ['from', 'to']
                }
            },
            {
                name: 'calls',
                schema: {
                    fields: {
                        from: { type: 'string', required: true },
                        to: { type: 'string', required: true },
                        type: { type: 'string', required: false },
                        status: { type: 'string', required: true }
                    },
                    indexes: ['from', 'to', 'status']
                }
            },
            {
                name: 'contacts',
                schema: {
                    fields: {
                        userId: { type: 'string', required: true },
                        contactId: { type: 'string', required: true },
                        status: { type: 'string', required: false }
                    },
                    indexes: ['userId', 'contactId']
                }
            }
        ];

        for (const { name, schema } of collections) {
            try {
                if (!this.db.getCollections().includes(name)) {
                    await this.db.createCollection(name, schema);
                    this.logger.info(`Created collection: ${name}`);
                }
            } catch (error) {
                this.logger.error(`Failed to create collection ${name}`, { error: error.message });
            }
        }
    }

    /**
     * Create default admin user
     */
    async createDefaultAdmin() {
        try {
            const adminExists = await this.db.findOne('users', { role: 'admin' });

            if (!adminExists) {
                const hashedPassword = await this.authUtils.hashPassword(
                    process.env.ADMIN_PASSWORD || 'admin123'
                );

                await this.db.insert('users', {
                    username: process.env.ADMIN_USERNAME || 'admin',
                    email: process.env.ADMIN_EMAIL || 'admin@example.com',
                    password: hashedPassword,
                    role: 'admin',
                    active: true,
                    online: false,
                    status: 'offline',
                    customStatus: ''
                });

                this.logger.info('Default admin user created');
            }
        } catch (error) {
            this.logger.error('Failed to create default admin', { error: error.message });
        }
    }

    /**
     * Setup Express middleware
     */
    setupMiddleware() {
        // Security
        this.app.use(helmet({
            contentSecurityPolicy: false // Disable for admin panel
        }));

        // CORS
        this.app.use(cors({
            origin: '*',
            credentials: true
        }));

        // Compression
        this.app.use(compression());

        // Body parsing
        this.app.use(express.json({ limit: '10mb' }));
        this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

        // Rate limiting
        const limiter = rateLimit({
            windowMs: 60 * 1000, // 1 minute
            max: parseInt(process.env.API_RATE_LIMIT) || 100,
            message: 'Too many requests from this IP'
        });
        this.app.use('/api/', limiter);

        // Static files for admin panel
        this.app.use('/admin', express.static(path.join(__dirname, 'admin/public')));

        // Request logging
        this.app.use((req, res, next) => {
            this.logger.info(`${req.method} ${req.path}`, {
                ip: req.ip,
                userAgent: req.get('user-agent')
            });
            next();
        });
    }

    /**
     * Setup API routes
     */
    setupRoutes() {
        // Health check
        this.app.get('/health', (req, res) => {
            res.json({
                status: 'healthy',
                uptime: process.uptime(),
                timestamp: new Date().toISOString(),
                version: '1.0.0'
            });
        });

        // Server info
        this.app.get('/api/v1/info', (req, res) => {
            res.json({
                name: 'Universal Node.js Server',
                version: '1.0.0',
                features: {
                    database: true,
                    ai: !!this.aiEngine,
                    realtime: !!this.realtimeEngine,
                    multiTenant: process.env.MULTI_TENANT_ENABLED === 'true'
                },
                endpoints: {
                    users: '/api/v1/users',
                    apps: '/api/v1/apps',
                    database: '/api/v1/database',
                    admin: '/admin'
                }
            });
        });

        // User routes (public registration/login)
        const userRoutes = createUserRoutes(this.db, this.authUtils, this.logger);
        this.app.use('/api/v1/users', userRoutes);

        // Protected routes (require authentication)
        const authMiddleware = authenticateJWT(this.authUtils);

        // App routes
        const appRoutes = createAppRoutes(this.db, this.authUtils, this.logger, this.aiEngine);
        this.app.use('/api/v1/apps', authMiddleware, appRoutes);

        // Database routes (admin only)
        const databaseRoutes = createDatabaseRoutes(this.db, this.logger, this.aiEngine);
        this.app.use('/api/v1/database', authMiddleware, requireRole('admin'), databaseRoutes);

        // AI routes (admin only)
        if (this.aiEngine) {
            this.setupAIRoutes();
        }

        // Realtime stats
        if (this.realtimeEngine) {
            this.app.get('/api/v1/realtime/stats', authMiddleware, requireRole('admin'), (req, res) => {
                res.json({
                    success: true,
                    stats: this.realtimeEngine.getStats()
                });
            });

            this.app.get('/api/v1/realtime/users', authMiddleware, requireRole('admin'), (req, res) => {
                res.json({
                    success: true,
                    users: this.realtimeEngine.getActiveUsers()
                });
            });
        }

        // Admin panel route
        this.app.get('/admin', (req, res) => {
            res.sendFile(path.join(__dirname, 'admin/public/index.html'));
        });

        // 404 handler
        this.app.use((req, res) => {
            res.status(404).json({
                error: 'Not found',
                path: req.path
            });
        });

        // Error handler
        this.app.use((err, req, res, next) => {
            this.logger.error('Server error', { error: err.message, stack: err.stack });
            res.status(500).json({
                error: 'Internal server error',
                message: process.env.NODE_ENV === 'development' ? err.message : undefined
            });
        });
    }

    /**
     * Setup AI-specific routes
     */
    setupAIRoutes() {
        const authMiddleware = authenticateJWT(this.authUtils);

        this.app.post('/api/v1/ai/test', authMiddleware, requireRole('admin'), async (req, res) => {
            try {
                const result = await this.aiEngine.testConnection();
                res.json(result);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.post('/api/v1/ai/optimize', authMiddleware, requireRole('admin'), async (req, res) => {
            try {
                const { context } = req.body;
                const result = await this.aiEngine.getOptimizationSuggestions(context);
                res.json(result);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.post('/api/v1/ai/security', authMiddleware, requireRole('admin'), async (req, res) => {
            try {
                const { appConfig } = req.body;
                const result = await this.aiEngine.getSecurityRecommendations(appConfig);
                res.json(result);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.post('/api/v1/ai/generate-app', authMiddleware, requireRole('admin'), async (req, res) => {
            try {
                const { description } = req.body;
                const result = await this.aiEngine.generateCompleteApp(description);
                res.json(result);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
    }

    /**
     * Start the server
     */
    async start() {
        try {
            await this.initialize();

            this.httpServer.listen(this.port, this.host, () => {
                console.log('\n✅ Server started successfully!\n');
                console.log(`🌐 Server running at: http://${this.host}:${this.port}`);
                console.log(`📊 Admin Panel: http://${this.host}:${this.port}/admin`);
                console.log(`🔌 API Base URL: http://${this.host}:${this.port}/api/v1`);

                if (this.realtimeEngine) {
                    console.log(`⚡ WebSocket: ws://${this.host}:${this.port}`);
                }

                if (this.aiEngine) {
                    console.log(`🤖 AI Integration: Enabled`);
                }

                console.log(`\n📝 Default Admin Credentials:`);
                console.log(`   Username: ${process.env.ADMIN_USERNAME || 'admin'}`);
                console.log(`   Password: ${process.env.ADMIN_PASSWORD || 'admin123'}`);
                console.log(`\n⚠️  Change default credentials in production!\n`);

                this.logger.info('Server started', { port: this.port, host: this.host });
            });

            // Graceful shutdown
            process.on('SIGTERM', () => this.shutdown());
            process.on('SIGINT', () => this.shutdown());

        } catch (error) {
            console.error('❌ Failed to start server:', error);
            process.exit(1);
        }
    }

    /**
     * Graceful shutdown
     */
    async shutdown() {
        console.log('\n🛑 Shutting down server...');

        this.httpServer.close(() => {
            console.log('HTTP server closed');
        });

        if (this.db) {
            await this.db.shutdown();
            console.log('Database closed');
        }

        if (this.realtimeEngine) {
            this.realtimeEngine.io.close();
            console.log('WebSocket server closed');
        }

        this.logger.info('Server shutdown complete');
        process.exit(0);
    }
}

// Start the server
const server = new UniversalServer();
server.start();

export default UniversalServer;
