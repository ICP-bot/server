# Universal Node.js Server - Quick Start Guide

## 🎉 Server is Running!

Your Universal Node.js Server is now live at:
- **Server**: http://localhost:3000
- **Admin Panel**: http://localhost:3000/admin
- **API Base**: http://localhost:3000/api/v1
- **WebSocket**: ws://localhost:3000

---

## 🔐 Default Admin Credentials

```
Username: admin
Password: admin123
```

⚠️ **IMPORTANT**: Change these credentials in production!

---

## 🚀 Quick Test Guide

### 1. Test Server Health

Open your browser or use curl:

```bash
curl http://localhost:3000/health
```

Expected response:
```json
{
  "status": "healthy",
  "uptime": 123.456,
  "timestamp": "2024-01-01T00:00:00.000Z",
  "version": "1.0.0"
}
```

### 2. Access Admin Panel

1. Open browser: http://localhost:3000/admin
2. Login with:
   - Username: `admin`
   - Password: `admin123`
3. Explore the dashboard!

### 3. Test API - Register a User

```bash
curl -X POST http://localhost:3000/api/v1/users/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123"
  }'
```

### 4. Test API - Login

```bash
curl -X POST http://localhost:3000/api/v1/users/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'
```

Save the token from the response!

### 5. Test Protected Endpoint

```bash
curl http://localhost:3000/api/v1/users/me \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

---

## 📋 Available Features

### ✅ Working Features

1. **User Management**
   - ✅ Registration
   - ✅ Login/Authentication
   - ✅ JWT tokens
   - ✅ Role-based access
   - ✅ Password hashing

2. **Database**
   - ✅ Custom internal database
   - ✅ CRUD operations
   - ✅ Indexing
   - ✅ Query support
   - ✅ Backup/Restore
   - ✅ Import/Export

3. **App Management**
   - ✅ App registration
   - ✅ API key generation
   - ✅ SDK generation
   - ✅ Statistics tracking

4. **Realtime**
   - ✅ WebSocket connections
   - ✅ Authentication
   - ✅ Presence tracking
   - ✅ Messaging
   - ✅ Call signaling
   - ✅ Database sync

5. **Admin Panel**
   - ✅ Dashboard with charts
   - ✅ User management UI
   - ✅ App management UI
   - ✅ Database management UI
   - ✅ AI assistant UI
   - ✅ Dark/Light theme

6. **Security**
   - ✅ JWT authentication
   - ✅ API key auth
   - ✅ Rate limiting
   - ✅ Password hashing
   - ✅ RBAC
   - ✅ Encryption support

7. **AI Integration** (Optional)
   - ⚠️ Requires Hugging Face API token
   - ✅ Schema generation
   - ✅ API generation
   - ✅ App generation
   - ✅ Optimization suggestions

---

## 🔧 Configuration

### Enable AI Features

1. Get a Hugging Face API token: https://huggingface.co/settings/tokens
2. Edit `.env` file:
   ```env
   HUGGINGFACE_API_TOKEN=your_token_here
   ```
3. Restart the server

### Change Admin Credentials

Edit `.env` file:
```env
ADMIN_USERNAME=your_admin
ADMIN_PASSWORD=your_secure_password
```

### Enable Database Encryption

Edit `.env` file:
```env
ENCRYPTION_KEY=your-32-character-encryption-key
```

---

## 📱 WebSocket Example

### JavaScript Client

```javascript
// Install: npm install socket.io-client
import io from 'socket.io-client';

const socket = io('http://localhost:3000');

// Authenticate
socket.emit('authenticate', {
  token: 'YOUR_JWT_TOKEN'
});

socket.on('auth:success', (data) => {
  console.log('Connected!', data);
});

// Listen to database changes
socket.on('db:insert', (data) => {
  console.log('New document:', data);
});

// Send a message
socket.emit('message:send', {
  to: 'user_id',
  message: 'Hello!',
  type: 'text'
});
```

---

## 🗂️ Database Collections

The server automatically creates these collections:

1. **users** - User accounts
2. **apps** - Registered applications
3. **messages** - Chat messages
4. **calls** - Call history
5. **contacts** - User contacts

You can create custom collections via:
- Admin Panel → Database → Create Collection
- API: `POST /api/v1/database/collections`

---

## 📊 API Endpoints Summary

### Public Endpoints
```
POST /api/v1/users/register    - Register new user
POST /api/v1/users/login       - Login user
GET  /health                   - Health check
GET  /api/v1/info              - Server info
```

### Protected Endpoints (Require JWT)
```
GET  /api/v1/users/me          - Get current user
PUT  /api/v1/users/me          - Update current user
GET  /api/v1/apps              - List apps
POST /api/v1/apps/register     - Register app
```

### Admin Only Endpoints
```
GET    /api/v1/users                    - List all users
GET    /api/v1/database/collections     - List collections
POST   /api/v1/database/collections     - Create collection
POST   /api/v1/ai/generate-app          - Generate app with AI
```

---

## 🎯 Next Steps

1. **Explore Admin Panel**
   - Login at http://localhost:3000/admin
   - View dashboard statistics
   - Create test users
   - Register test apps

2. **Test APIs**
   - Use Postman or curl
   - Try user registration
   - Test authentication
   - Create database collections

3. **Try AI Features** (if enabled)
   - Generate database schemas
   - Create complete apps
   - Get optimization suggestions

4. **Test Realtime**
   - Connect via WebSocket
   - Send messages
   - Monitor database changes

5. **Customize**
   - Modify `.env` settings
   - Add custom collections
   - Create custom APIs
   - Extend functionality

---

## 🐛 Troubleshooting

### Server won't start
- Check if port 3000 is available
- Verify Node.js version (>= 18.0.0)
- Check `.env` file exists

### Can't login to admin panel
- Verify credentials: admin/admin123
- Check browser console for errors
- Ensure server is running

### AI features not working
- Add HUGGINGFACE_API_TOKEN to `.env`
- Restart server
- Check Hugging Face API status

### Database errors
- Check `db/data` directory exists
- Verify write permissions
- Check disk space

---

## 📚 Documentation

Full documentation available in `README.md`

---

## 🎊 Congratulations!

Your Universal Node.js Server is ready to use!

**Features:**
✅ Custom Database
✅ REST APIs
✅ WebSocket/Realtime
✅ Admin Panel
✅ AI Integration
✅ Multi-Tenant Support
✅ Security & Authentication

**Happy Coding! 🚀**
