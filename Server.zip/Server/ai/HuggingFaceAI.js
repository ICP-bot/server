import OpenAI from 'openai';

/**
 * Hugging Face AI Integration using OpenAI-compatible Router
 * Uses OpenAI SDK with Hugging Face Router for GPT-OSS-120B model
 */
class HuggingFaceAI {
    constructor(apiToken, model = 'openai/gpt-oss-120b:groq', baseURL = 'https://router.huggingface.co/v1') {
        this.apiToken = apiToken;
        this.model = model;
        this.baseURL = baseURL;

        // Initialize OpenAI client with Hugging Face Router
        this.client = new OpenAI({
            baseURL: this.baseURL,
            apiKey: this.apiToken,
        });

        this.maxRetries = 3;
        this.retryDelay = 1000;
    }

    /**
     * Generate database schema from natural language prompt
     */
    async generateSchema(prompt) {
        const systemPrompt = `You are a database schema expert. Generate a JSON schema for a database collection based on the user's description.

Return ONLY valid JSON in this exact format (no markdown, no code blocks):
{
  "collectionName": "name_here",
  "schema": {
    "fields": {
      "fieldName": {
        "type": "string|number|boolean|object|array",
        "required": true|false,
        "description": "field description"
      }
    },
    "indexes": ["field1", "field2"],
    "relations": {
      "fieldName": {
        "collection": "related_collection",
        "type": "one-to-one|one-to-many|many-to-many"
      }
    }
  }
}`;

        try {
            const response = await this.query([
                { role: 'system', content: systemPrompt },
                { role: 'user', content: prompt }
            ]);

            const schema = this.extractJSON(response);

            return {
                success: true,
                schema,
                rawResponse: response
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                rawResponse: null
            };
        }
    }

    /**
     * Generate API endpoints from schema
     */
    async generateAPIs(schema, collectionName) {
        const systemPrompt = `You are an API design expert. Generate REST API endpoints for a collection.

Return ONLY valid JSON in this exact format (no markdown, no code blocks):
{
  "endpoints": [
    {
      "method": "GET|POST|PUT|DELETE",
      "path": "/api/v1/resource",
      "description": "endpoint description",
      "auth": true|false,
      "roles": ["admin", "user"],
      "params": ["param1"],
      "body": {"field": "type"},
      "response": {"field": "type"}
    }
  ]
}`;

        const userPrompt = `Collection: ${collectionName}\nSchema: ${JSON.stringify(schema, null, 2)}\n\nGenerate the REST API endpoints.`;

        try {
            const response = await this.query([
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ]);

            const apis = this.extractJSON(response);

            return {
                success: true,
                apis,
                rawResponse: response
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                rawResponse: null
            };
        }
    }

    /**
     * Generate SDK/JSON configuration for apps
     */
    async generateSDK(appName, baseUrl, apiKey, endpoints) {
        const systemPrompt = `You are an SDK generator. Create a JSON configuration file for client apps to integrate with the server.

Return ONLY valid JSON in this exact format (no markdown, no code blocks):
{
  "appName": "app_name",
  "version": "1.0.0",
  "baseUrl": "http://example.com",
  "auth": {
    "type": "bearer|apiKey",
    "apiKey": "key_here"
  },
  "endpoints": {
    "endpointName": {
      "method": "GET|POST|PUT|DELETE",
      "path": "/api/path",
      "description": "description"
    }
  },
  "websocket": {
    "enabled": true|false,
    "url": "ws://example.com",
    "events": ["event1", "event2"]
  }
}`;

        const userPrompt = `App: ${appName}\nBase URL: ${baseUrl}\nAPI Key: ${apiKey}\nEndpoints: ${JSON.stringify(endpoints, null, 2)}\n\nGenerate the SDK configuration.`;

        try {
            const response = await this.query([
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ]);

            const sdk = this.extractJSON(response);

            return {
                success: true,
                sdk,
                rawResponse: response
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                rawResponse: null
            };
        }
    }

    /**
     * Get optimization suggestions
     */
    async getOptimizationSuggestions(context) {
        const systemPrompt = `You are a server optimization expert. Analyze the provided context and suggest improvements.

Return ONLY valid JSON in this exact format (no markdown, no code blocks):
{
  "suggestions": [
    {
      "category": "performance|security|scalability|architecture",
      "priority": "high|medium|low",
      "title": "suggestion title",
      "description": "detailed description",
      "implementation": "how to implement"
    }
  ]
}`;

        const userPrompt = `Context: ${JSON.stringify(context, null, 2)}\n\nProvide optimization suggestions.`;

        try {
            const response = await this.query([
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ]);

            const suggestions = this.extractJSON(response);

            return {
                success: true,
                suggestions,
                rawResponse: response
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                rawResponse: null
            };
        }
    }

    /**
     * Generate security recommendations
     */
    async getSecurityRecommendations(appConfig) {
        const systemPrompt = `You are a security expert. Analyze the app configuration and provide security recommendations.

Return ONLY valid JSON in this exact format (no markdown, no code blocks):
{
  "recommendations": [
    {
      "severity": "critical|high|medium|low",
      "title": "recommendation title",
      "description": "detailed description",
      "fix": "how to fix"
    }
  ]
}`;

        const userPrompt = `App Config: ${JSON.stringify(appConfig, null, 2)}\n\nProvide security recommendations.`;

        try {
            const response = await this.query([
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ]);

            const recommendations = this.extractJSON(response);

            return {
                success: true,
                recommendations,
                rawResponse: response
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                rawResponse: null
            };
        }
    }

    /**
     * Query OpenAI-compatible API with streaming support
     */
    async query(messages, retries = 0) {
        if (!this.apiToken) {
            throw new Error('Hugging Face API token not configured');
        }

        try {
            const completion = await this.client.chat.completions.create({
                model: this.model,
                messages: messages,
                temperature: 0.7,
                max_tokens: 2000,
                stream: false // We'll use non-streaming for JSON responses
            });

            return completion.choices[0]?.message?.content || '';
        } catch (error) {
            if (retries < this.maxRetries) {
                console.log(`Request failed, retrying... (${retries + 1}/${this.maxRetries})`);
                await this.sleep(this.retryDelay);
                return this.query(messages, retries + 1);
            }
            throw error;
        }
    }

    /**
     * Query with streaming (for real-time responses)
     */
    async queryStream(messages, onChunk) {
        if (!this.apiToken) {
            throw new Error('Hugging Face API token not configured');
        }

        try {
            const stream = await this.client.chat.completions.create({
                model: this.model,
                messages: messages,
                temperature: 0.7,
                max_tokens: 2000,
                stream: true
            });

            let fullResponse = '';

            for await (const chunk of stream) {
                const content = chunk.choices[0]?.delta?.content || '';
                fullResponse += content;
                if (onChunk) {
                    onChunk(content);
                }
            }

            return fullResponse;
        } catch (error) {
            throw error;
        }
    }

    /**
     * Extract JSON from AI response
     */
    extractJSON(text) {
        try {
            // Remove markdown code blocks if present
            let cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '');

            // Try to parse directly
            return JSON.parse(cleaned);
        } catch (e) {
            // Try to find JSON in text
            const jsonMatch = text.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                try {
                    return JSON.parse(jsonMatch[0]);
                } catch (e2) {
                    // Try to clean up common issues
                    let cleaned = jsonMatch[0]
                        .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
                        .replace(/'/g, '"') // Replace single quotes
                        .replace(/(\w+):/g, '"$1":'); // Quote keys

                    return JSON.parse(cleaned);
                }
            }

            throw new Error('Could not extract valid JSON from response');
        }
    }

    /**
     * Sleep utility
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * Test connection
     */
    async testConnection() {
        try {
            const response = await this.query([
                { role: 'user', content: 'Hello! Please respond with a simple greeting.' }
            ]);

            return {
                success: true,
                message: 'AI connection successful',
                response
            };
        } catch (error) {
            return {
                success: false,
                message: 'AI connection failed',
                error: error.message
            };
        }
    }

    /**
     * Generate complete app from description
     */
    async generateCompleteApp(description) {
        const systemPrompt = `You are a full-stack application architect. Generate a complete app specification including database schema, APIs, and features.

Return ONLY valid JSON in this exact format (no markdown, no code blocks):
{
  "appName": "app_name",
  "description": "app description",
  "collections": [
    {
      "name": "collection_name",
      "schema": {
        "fields": {},
        "indexes": []
      }
    }
  ],
  "apis": [
    {
      "method": "GET|POST|PUT|DELETE",
      "path": "/api/path",
      "description": "description"
    }
  ],
  "features": [
    {
      "name": "feature name",
      "description": "feature description",
      "endpoints": ["/api/path"]
    }
  ],
  "websocketEvents": ["event1", "event2"]
}`;

        const userPrompt = `App Description: ${description}\n\nGenerate the complete app specification.`;

        try {
            const response = await this.query([
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ]);

            const appSpec = this.extractJSON(response);

            return {
                success: true,
                appSpec,
                rawResponse: response
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                rawResponse: null
            };
        }
    }

    /**
     * Chat completion (general purpose)
     */
    async chat(userMessage, systemMessage = null) {
        const messages = [];

        if (systemMessage) {
            messages.push({ role: 'system', content: systemMessage });
        }

        messages.push({ role: 'user', content: userMessage });

        try {
            const response = await this.query(messages);
            return {
                success: true,
                response
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }
}

export default HuggingFaceAI;
