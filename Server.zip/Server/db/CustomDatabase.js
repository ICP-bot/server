import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { EventEmitter } from 'events';

/**
 * Custom Internal Database System
 * Supports JSON/Binary/In-Memory storage with realtime sync
 */
class CustomDatabase extends EventEmitter {
  constructor(options = {}) {
    super();
    this.storageType = options.storageType || 'json';
    this.dataDir = options.dataDir || './db/data';
    this.backupDir = options.backupDir || './db/backups';
    this.encryptionKey = options.encryptionKey || null;
    this.persistenceInterval = options.persistenceInterval || 60000;
    
    // In-memory storage
    this.collections = new Map();
    this.indexes = new Map();
    this.schema = new Map();
    
    // Metadata
    this.metadata = {
      version: '1.0.0',
      createdAt: new Date().toISOString(),
      lastModified: new Date().toISOString()
    };
    
    this.initialized = false;
    this.persistenceTimer = null;
  }

  /**
   * Initialize database
   */
  async initialize() {
    if (this.initialized) return;
    
    try {
      // Create directories
      await fs.mkdir(this.dataDir, { recursive: true });
      await fs.mkdir(this.backupDir, { recursive: true });
      
      // Load existing data
      await this.loadFromDisk();
      
      // Start persistence timer
      this.startPersistence();
      
      this.initialized = true;
      this.emit('initialized');
      console.log('✅ Database initialized successfully');
    } catch (error) {
      console.error('❌ Database initialization failed:', error);
      throw error;
    }
  }

  /**
   * Create a new collection
   */
  async createCollection(name, schema = {}) {
    if (this.collections.has(name)) {
      throw new Error(`Collection '${name}' already exists`);
    }
    
    this.collections.set(name, new Map());
    this.schema.set(name, schema);
    this.indexes.set(name, new Map());
    
    // Create default indexes
    if (schema.indexes) {
      for (const indexField of schema.indexes) {
        this.createIndex(name, indexField);
      }
    }
    
    await this.persistToDisk();
    this.emit('collection:created', { collection: name, schema });
    
    return true;
  }

  /**
   * Create index for faster queries
   */
  createIndex(collectionName, field) {
    if (!this.collections.has(collectionName)) {
      throw new Error(`Collection '${collectionName}' does not exist`);
    }
    
    const collectionIndexes = this.indexes.get(collectionName);
    if (!collectionIndexes.has(field)) {
      collectionIndexes.set(field, new Map());
    }
    
    // Build index from existing data
    const collection = this.collections.get(collectionName);
    const index = collectionIndexes.get(field);
    
    for (const [id, doc] of collection) {
      const value = this.getNestedValue(doc, field);
      if (value !== undefined) {
        if (!index.has(value)) {
          index.set(value, new Set());
        }
        index.get(value).add(id);
      }
    }
  }

  /**
   * Insert document into collection
   */
  async insert(collectionName, document) {
    if (!this.collections.has(collectionName)) {
      throw new Error(`Collection '${collectionName}' does not exist`);
    }
    
    const collection = this.collections.get(collectionName);
    const schema = this.schema.get(collectionName);
    
    // Generate ID if not provided
    const id = document._id || this.generateId();
    
    // Validate against schema
    if (schema.fields) {
      this.validateDocument(document, schema);
    }
    
    // Add metadata
    const doc = {
      ...document,
      _id: id,
      _createdAt: new Date().toISOString(),
      _updatedAt: new Date().toISOString()
    };
    
    collection.set(id, doc);
    
    // Update indexes
    this.updateIndexes(collectionName, id, doc);
    
    this.emit('document:inserted', { collection: collectionName, document: doc });
    
    return doc;
  }

  /**
   * Find documents in collection
   */
  find(collectionName, query = {}, options = {}) {
    if (!this.collections.has(collectionName)) {
      throw new Error(`Collection '${collectionName}' does not exist`);
    }
    
    const collection = this.collections.get(collectionName);
    let results = [];
    
    // Check if we can use index
    const indexedField = this.findIndexedField(collectionName, query);
    
    if (indexedField) {
      // Use index for faster lookup
      const index = this.indexes.get(collectionName).get(indexedField);
      const value = query[indexedField];
      const ids = index.get(value) || new Set();
      
      for (const id of ids) {
        const doc = collection.get(id);
        if (this.matchesQuery(doc, query)) {
          results.push(doc);
        }
      }
    } else {
      // Full collection scan
      for (const doc of collection.values()) {
        if (this.matchesQuery(doc, query)) {
          results.push(doc);
        }
      }
    }
    
    // Apply options (sort, limit, skip)
    if (options.sort) {
      results = this.sortResults(results, options.sort);
    }
    
    if (options.skip) {
      results = results.slice(options.skip);
    }
    
    if (options.limit) {
      results = results.slice(0, options.limit);
    }
    
    return results;
  }

  /**
   * Find one document
   */
  findOne(collectionName, query = {}) {
    const results = this.find(collectionName, query, { limit: 1 });
    return results[0] || null;
  }

  /**
   * Find by ID
   */
  findById(collectionName, id) {
    if (!this.collections.has(collectionName)) {
      throw new Error(`Collection '${collectionName}' does not exist`);
    }
    
    return this.collections.get(collectionName).get(id) || null;
  }

  /**
   * Update document
   */
  async update(collectionName, query, update, options = {}) {
    if (!this.collections.has(collectionName)) {
      throw new Error(`Collection '${collectionName}' does not exist`);
    }
    
    const collection = this.collections.get(collectionName);
    const docs = this.find(collectionName, query);
    
    if (docs.length === 0) {
      return { matched: 0, modified: 0 };
    }
    
    const updateOne = options.updateOne || false;
    const docsToUpdate = updateOne ? [docs[0]] : docs;
    let modified = 0;
    
    for (const doc of docsToUpdate) {
      const updatedDoc = {
        ...doc,
        ...update,
        _id: doc._id, // Preserve ID
        _createdAt: doc._createdAt, // Preserve creation time
        _updatedAt: new Date().toISOString()
      };
      
      collection.set(doc._id, updatedDoc);
      this.updateIndexes(collectionName, doc._id, updatedDoc, doc);
      
      this.emit('document:updated', { 
        collection: collectionName, 
        document: updatedDoc,
        oldDocument: doc 
      });
      
      modified++;
    }
    
    return { matched: docs.length, modified };
  }

  /**
   * Delete document
   */
  async delete(collectionName, query, options = {}) {
    if (!this.collections.has(collectionName)) {
      throw new Error(`Collection '${collectionName}' does not exist`);
    }
    
    const collection = this.collections.get(collectionName);
    const docs = this.find(collectionName, query);
    
    if (docs.length === 0) {
      return { deleted: 0 };
    }
    
    const deleteOne = options.deleteOne || false;
    const docsToDelete = deleteOne ? [docs[0]] : docs;
    let deleted = 0;
    
    for (const doc of docsToDelete) {
      collection.delete(doc._id);
      this.removeFromIndexes(collectionName, doc._id, doc);
      
      this.emit('document:deleted', { collection: collectionName, document: doc });
      
      deleted++;
    }
    
    return { deleted };
  }

  /**
   * Count documents
   */
  count(collectionName, query = {}) {
    return this.find(collectionName, query).length;
  }

  /**
   * Get all collections
   */
  getCollections() {
    return Array.from(this.collections.keys());
  }

  /**
   * Get collection schema
   */
  getSchema(collectionName) {
    return this.schema.get(collectionName) || null;
  }

  /**
   * Drop collection
   */
  async dropCollection(collectionName) {
    if (!this.collections.has(collectionName)) {
      throw new Error(`Collection '${collectionName}' does not exist`);
    }
    
    this.collections.delete(collectionName);
    this.schema.delete(collectionName);
    this.indexes.delete(collectionName);
    
    await this.persistToDisk();
    this.emit('collection:dropped', { collection: collectionName });
    
    return true;
  }

  /**
   * Backup database
   */
  async backup(backupName) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = backupName || `backup-${timestamp}.json`;
    const backupPath = path.join(this.backupDir, filename);
    
    const data = this.exportData();
    
    if (this.encryptionKey) {
      const encrypted = this.encrypt(JSON.stringify(data));
      await fs.writeFile(backupPath, encrypted);
    } else {
      await fs.writeFile(backupPath, JSON.stringify(data, null, 2));
    }
    
    this.emit('backup:created', { path: backupPath });
    
    return backupPath;
  }

  /**
   * Restore from backup
   */
  async restore(backupPath) {
    const data = await fs.readFile(backupPath, 'utf-8');
    
    let parsed;
    if (this.encryptionKey) {
      const decrypted = this.decrypt(data);
      parsed = JSON.parse(decrypted);
    } else {
      parsed = JSON.parse(data);
    }
    
    this.importData(parsed);
    await this.persistToDisk();
    
    this.emit('backup:restored', { path: backupPath });
    
    return true;
  }

  /**
   * Export database data
   */
  exportData() {
    const data = {
      metadata: this.metadata,
      collections: {},
      schema: {}
    };
    
    for (const [name, collection] of this.collections) {
      data.collections[name] = Array.from(collection.values());
      data.schema[name] = this.schema.get(name);
    }
    
    return data;
  }

  /**
   * Import database data
   */
  importData(data) {
    this.metadata = data.metadata || this.metadata;
    
    // Clear existing data
    this.collections.clear();
    this.schema.clear();
    this.indexes.clear();
    
    // Import collections
    for (const [name, docs] of Object.entries(data.collections)) {
      const collection = new Map();
      for (const doc of docs) {
        collection.set(doc._id, doc);
      }
      this.collections.set(name, collection);
      this.schema.set(name, data.schema[name] || {});
      this.indexes.set(name, new Map());
      
      // Rebuild indexes
      const schema = this.schema.get(name);
      if (schema.indexes) {
        for (const field of schema.indexes) {
          this.createIndex(name, field);
        }
      }
    }
  }

  /**
   * Persist data to disk
   */
  async persistToDisk() {
    const data = this.exportData();
    
    for (const [name, docs] of Object.entries(data.collections)) {
      const filePath = path.join(this.dataDir, `${name}.json`);
      
      if (this.encryptionKey) {
        const encrypted = this.encrypt(JSON.stringify({ docs, schema: data.schema[name] }));
        await fs.writeFile(filePath, encrypted);
      } else {
        await fs.writeFile(filePath, JSON.stringify({ docs, schema: data.schema[name] }, null, 2));
      }
    }
    
    this.metadata.lastModified = new Date().toISOString();
  }

  /**
   * Load data from disk
   */
  async loadFromDisk() {
    try {
      const files = await fs.readdir(this.dataDir);
      
      for (const file of files) {
        if (!file.endsWith('.json')) continue;
        
        const collectionName = file.replace('.json', '');
        const filePath = path.join(this.dataDir, file);
        const content = await fs.readFile(filePath, 'utf-8');
        
        let parsed;
        if (this.encryptionKey) {
          const decrypted = this.decrypt(content);
          parsed = JSON.parse(decrypted);
        } else {
          parsed = JSON.parse(content);
        }
        
        const collection = new Map();
        for (const doc of parsed.docs) {
          collection.set(doc._id, doc);
        }
        
        this.collections.set(collectionName, collection);
        this.schema.set(collectionName, parsed.schema || {});
        this.indexes.set(collectionName, new Map());
        
        // Rebuild indexes
        if (parsed.schema?.indexes) {
          for (const field of parsed.schema.indexes) {
            this.createIndex(collectionName, field);
          }
        }
      }
    } catch (error) {
      if (error.code !== 'ENOENT') {
        console.error('Error loading from disk:', error);
      }
    }
  }

  /**
   * Start automatic persistence
   */
  startPersistence() {
    if (this.persistenceTimer) {
      clearInterval(this.persistenceTimer);
    }
    
    this.persistenceTimer = setInterval(async () => {
      await this.persistToDisk();
    }, this.persistenceInterval);
  }

  /**
   * Stop persistence
   */
  stopPersistence() {
    if (this.persistenceTimer) {
      clearInterval(this.persistenceTimer);
      this.persistenceTimer = null;
    }
  }

  /**
   * Shutdown database
   */
  async shutdown() {
    this.stopPersistence();
    await this.persistToDisk();
    this.emit('shutdown');
  }

  // Helper methods

  generateId() {
    return crypto.randomBytes(16).toString('hex');
  }

  validateDocument(doc, schema) {
    if (!schema.fields) return true;
    
    for (const [field, rules] of Object.entries(schema.fields)) {
      if (rules.required && doc[field] === undefined) {
        throw new Error(`Field '${field}' is required`);
      }
      
      if (doc[field] !== undefined && rules.type) {
        const actualType = typeof doc[field];
        if (actualType !== rules.type) {
          throw new Error(`Field '${field}' must be of type '${rules.type}'`);
        }
      }
    }
    
    return true;
  }

  matchesQuery(doc, query) {
    for (const [key, value] of Object.entries(query)) {
      const docValue = this.getNestedValue(doc, key);
      
      if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
        // Handle operators
        for (const [op, opValue] of Object.entries(value)) {
          if (!this.evaluateOperator(docValue, op, opValue)) {
            return false;
          }
        }
      } else {
        if (docValue !== value) {
          return false;
        }
      }
    }
    
    return true;
  }

  evaluateOperator(value, operator, operand) {
    switch (operator) {
      case '$eq': return value === operand;
      case '$ne': return value !== operand;
      case '$gt': return value > operand;
      case '$gte': return value >= operand;
      case '$lt': return value < operand;
      case '$lte': return value <= operand;
      case '$in': return Array.isArray(operand) && operand.includes(value);
      case '$nin': return Array.isArray(operand) && !operand.includes(value);
      case '$exists': return (value !== undefined) === operand;
      default: return true;
    }
  }

  getNestedValue(obj, path) {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  findIndexedField(collectionName, query) {
    const collectionIndexes = this.indexes.get(collectionName);
    for (const field of collectionIndexes.keys()) {
      if (query[field] !== undefined && typeof query[field] !== 'object') {
        return field;
      }
    }
    return null;
  }

  updateIndexes(collectionName, id, newDoc, oldDoc = null) {
    const collectionIndexes = this.indexes.get(collectionName);
    
    for (const [field, index] of collectionIndexes) {
      // Remove old value from index
      if (oldDoc) {
        const oldValue = this.getNestedValue(oldDoc, field);
        if (oldValue !== undefined && index.has(oldValue)) {
          index.get(oldValue).delete(id);
        }
      }
      
      // Add new value to index
      const newValue = this.getNestedValue(newDoc, field);
      if (newValue !== undefined) {
        if (!index.has(newValue)) {
          index.set(newValue, new Set());
        }
        index.get(newValue).add(id);
      }
    }
  }

  removeFromIndexes(collectionName, id, doc) {
    const collectionIndexes = this.indexes.get(collectionName);
    
    for (const [field, index] of collectionIndexes) {
      const value = this.getNestedValue(doc, field);
      if (value !== undefined && index.has(value)) {
        index.get(value).delete(id);
      }
    }
  }

  sortResults(results, sortOptions) {
    return results.sort((a, b) => {
      for (const [field, order] of Object.entries(sortOptions)) {
        const aVal = this.getNestedValue(a, field);
        const bVal = this.getNestedValue(b, field);
        
        if (aVal < bVal) return order === 1 ? -1 : 1;
        if (aVal > bVal) return order === 1 ? 1 : -1;
      }
      return 0;
    });
  }

  encrypt(text) {
    if (!this.encryptionKey) return text;
    
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(this.encryptionKey.padEnd(32, '0').slice(0, 32)), iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return iv.toString('hex') + ':' + encrypted;
  }

  decrypt(text) {
    if (!this.encryptionKey) return text;
    
    const parts = text.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const encrypted = parts[1];
    
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(this.encryptionKey.padEnd(32, '0').slice(0, 32)), iv);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }
}

export default CustomDatabase;
