// Admin Panel JavaScript - Complete Implementation
// Admin Panel JavaScript - Complete Implementation
const API_BASE = window.location.origin + '/api/v1';
let authToken = localStorage.getItem('authToken');
let currentUser = null;
try {
    currentUser = localStorage.getItem('currentUser') ? JSON.parse(localStorage.getItem('currentUser')) : null;
} catch (e) {
    console.error('Failed to parse saved user:', e);
}

let currentPage = 'dashboard';

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Optimistic checking - if we have data, show dashboard immediately
    if (authToken && currentUser) {
        showDashboard();
        if (typeof initializeAIAssistant === 'function') initializeAIAssistant();
        // Verify in background
        verifyAuth(true);
    } else if (authToken) {
        verifyAuth();
    } else {
        showLoginPage();
    }

    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Navigation
    document.querySelectorAll('.sidebar .nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = e.currentTarget.dataset.page;
            navigateToPage(page);
        });
    });

    // Search and filters
    const userSearch = document.getElementById('user-search');
    if (userSearch) {
        userSearch.addEventListener('input', debounce(loadUsers, 300));
    }

    const userRoleFilter = document.getElementById('user-role-filter');
    if (userRoleFilter) {
        userRoleFilter.addEventListener('change', loadUsers);
    }

    const userStatusFilter = document.getElementById('user-status-filter');
    if (userStatusFilter) {
        userStatusFilter.addEventListener('change', loadUsers);
    }
}

// Authentication
async function handleLogin(e) {
    e.preventDefault();

    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    const errorDiv = document.getElementById('login-error');
    const submitBtn = e.target.querySelector('button[type="submit"]');

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Logging in...';

    try {
        const response = await fetch(`${API_BASE}/users/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('authToken', authToken);
            localStorage.setItem('currentUser', JSON.stringify(currentUser));

            errorDiv.style.display = 'none';
            showDashboard();
            if (typeof initializeAIAssistant === 'function') initializeAIAssistant();
        } else {
            errorDiv.textContent = data.error || 'Login failed';
            errorDiv.style.display = 'block';
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="bi bi-box-arrow-in-right"></i> Login';
        }
    } catch (error) {
        errorDiv.textContent = 'Connection error. Please check if the server is running.';
        errorDiv.style.display = 'block';
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="bi bi-box-arrow-in-right"></i> Login';
    }
}

async function verifyAuth(background = false) {
    try {
        const response = await apiRequest('/users/me');
        if (response.success) {
            currentUser = response.user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));

            // Only update UI if we're not already there or to ensure state
            if (!background || document.getElementById('login-page').style.display !== 'none') {
                showDashboard();
                if (typeof initializeAIAssistant === 'function') initializeAIAssistant();
            }
        } else {
            // If explicitly failed (and not caught by 401 interceptor), show login
            // But if background, maybe valid session but temp error? 
            // Usually success:false from /me means not logged in.
            if (!background) showLoginPage();
        }
    } catch (error) {
        console.error('Auth check error:', error);
        // If apiRequest caught 401, it already called logout()
        // Here we handle other errors (network). 
        // If background (optimistic load), don't show login page on network error
        if (!background) {
            showLoginPage();
        }
    }
}

function logout() {
    if (typeof destroyAIAssistant === 'function') destroyAIAssistant();
    authToken = null;
    currentUser = null;
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    showLoginPage();
}

// Page navigation
function showLoginPage() {
    document.querySelectorAll('.page-content').forEach(page => page.style.display = 'none');
    document.getElementById('login-page').style.display = 'block';
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.style.display = 'none';
}

function showDashboard() {
    document.getElementById('login-page').style.display = 'none';
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.style.display = 'block';
    navigateToPage('dashboard');
}

function navigateToPage(pageName) {
    currentPage = pageName;

    // Update active nav link
    document.querySelectorAll('.sidebar .nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.page === pageName) {
            link.classList.add('active');
        }
    });

    // Show page
    document.querySelectorAll('.page-content').forEach(page => page.style.display = 'none');
    const targetPage = document.getElementById(`${pageName}-page`);
    if (targetPage) {
        targetPage.style.display = 'block';

        // Load page data
        switch (pageName) {
            case 'dashboard':
                loadDashboard();
                break;
            case 'users':
                loadUsers();
                break;
            case 'apps':
                loadApps();
                break;
            case 'database':
                loadDatabase();
                break;
            case 'realtime':
                loadRealtime();
                break;
            case 'logs':
                loadLogs();
                break;
        }
    }
}

// Dashboard
async function loadDashboard() {
    if (currentUser) {
        document.getElementById('user-name').textContent = currentUser.username;
    }

    try {
        // Load stats
        const [usersRes, appsRes, dbRes, realtimeRes] = await Promise.all([
            apiRequest('/users').catch(() => ({ success: false })),
            apiRequest('/apps').catch(() => ({ success: false })),
            apiRequest('/database/stats').catch(() => ({ success: false })),
            apiRequest('/realtime/stats').catch(() => ({ success: false }))
        ]);

        if (usersRes.success) {
            document.getElementById('stat-users').textContent = usersRes.total || 0;
            const onlineUsers = usersRes.users?.filter(u => u.online).length || 0;
            document.getElementById('stat-online').textContent = onlineUsers;
        }

        if (appsRes.success) {
            const activeApps = appsRes.apps?.filter(a => a.active).length || 0;
            document.getElementById('stat-apps').textContent = activeApps;
        }

        if (dbRes.success) {
            document.getElementById('stat-collections').textContent = dbRes.stats?.totalCollections || 0;
        }

        // Initialize charts
        initializeCharts();

        // Load recent activity
        loadRecentActivity();

    } catch (error) {
        console.error('Failed to load dashboard:', error);
        showNotification('Failed to load dashboard data', 'error');
    }
}

function refreshDashboard() {
    showNotification('Refreshing dashboard...', 'info');
    loadDashboard();
}

let userActivityChart = null;
let apiCallsChart = null;

function initializeCharts() {
    // User Activity Chart
    const userCtx = document.getElementById('userActivityChart');
    if (userCtx) {
        if (userActivityChart) {
            userActivityChart.destroy();
        }
        userActivityChart = new Chart(userCtx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Active Users',
                    data: [12, 19, 15, 25, 22, 30, 28],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }

    // API Calls Chart
    const apiCtx = document.getElementById('apiCallsChart');
    if (apiCtx) {
        if (apiCallsChart) {
            apiCallsChart.destroy();
        }
        apiCallsChart = new Chart(apiCtx, {
            type: 'bar',
            data: {
                labels: Array.from({ length: 24 }, (_, i) => `${i}:00`),
                datasets: [{
                    label: 'API Calls',
                    data: Array.from({ length: 24 }, () => Math.floor(Math.random() * 100)),
                    backgroundColor: '#4facfe'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }
}

async function loadRecentActivity() {
    const container = document.getElementById('recent-activity');

    // Mock activity data - in production, fetch from logs
    const activities = [
        { type: 'user', message: 'New user registered: john_doe', time: '2 minutes ago', icon: 'bi-person-plus' },
        { type: 'app', message: 'App "MyApp" created', time: '15 minutes ago', icon: 'bi-grid' },
        { type: 'database', message: 'Collection "posts" created', time: '1 hour ago', icon: 'bi-database' },
        { type: 'ai', message: 'AI schema generated for "blog"', time: '2 hours ago', icon: 'bi-robot' },
        { type: 'system', message: 'Database backup completed', time: '3 hours ago', icon: 'bi-check-circle' }
    ];

    container.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <i class="bi ${activity.icon} me-2"></i>
                    <span>${activity.message}</span>
                </div>
                <small class="text-muted">${activity.time}</small>
            </div>
        </div>
    `).join('');
}

// Users Management
async function loadUsers() {
    const tbody = document.getElementById('users-table-body');
    const search = document.getElementById('user-search')?.value || '';
    const role = document.getElementById('user-role-filter')?.value || '';
    const status = document.getElementById('user-status-filter')?.value || '';

    tbody.innerHTML = '<tr><td colspan="6" class="text-center"><div class="spinner-border spinner-border-sm"></div> Loading...</td></tr>';

    try {
        let url = '/users?limit=100';
        if (search) url += `&search=${encodeURIComponent(search)}`;
        if (role) url += `&role=${role}`;
        if (status) url += `&status=${status}`;

        const response = await apiRequest(url);

        if (response.success && response.users) {
            if (response.users.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No users found</td></tr>';
                return;
            }

            tbody.innerHTML = response.users.map(user => `
                <tr>
                    <td>
                        <i class="bi bi-person-circle me-2"></i>
                        <strong>${escapeHtml(user.username)}</strong>
                    </td>
                    <td>${escapeHtml(user.email)}</td>
                    <td><span class="badge bg-primary">${escapeHtml(user.role)}</span></td>
                    <td>
                        <span class="badge ${user.online ? 'badge-online' : 'badge-offline'}">
                            <i class="bi ${user.online ? 'bi-circle-fill' : 'bi-circle'}"></i>
                            ${user.online ? 'Online' : 'Offline'}
                        </span>
                    </td>
                    <td><small>${formatDate(user.lastSeen)}</small></td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-info" onclick="viewUser('${user.id}')" title="View">
                                <i class="bi bi-eye"></i>
                            </button>
                            <button class="btn btn-warning" onclick="editUser('${user.id}')" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </button>
                            ${user.role !== 'admin' ? `
                            <button class="btn btn-danger" onclick="deleteUser('${user.id}', '${escapeHtml(user.username)}')" title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                            ` : ''}
                        </div>
                    </td>
                </tr>
            `).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-danger">Failed to load users</td></tr>';
        }
    } catch (error) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-danger">Error loading users</td></tr>';
        console.error('Load users error:', error);
    }
}

function showCreateUserModal() {
    const modal = createModal('Create User', `
        <form id="create-user-form">
            <div class="mb-3">
                <label class="form-label">Username *</label>
                <input type="text" class="form-control" id="new-username" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email *</label>
                <input type="email" class="form-control" id="new-email" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password *</label>
                <input type="password" class="form-control" id="new-password" required minlength="6">
            </div>
            <div class="mb-3">
                <label class="form-label">Role</label>
                <select class="form-select" id="new-role">
                    <option value="user">User</option>
                    <option value="moderator">Moderator</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
        </form>
    `, async () => {
        const username = document.getElementById('new-username').value;
        const email = document.getElementById('new-email').value;
        const password = document.getElementById('new-password').value;
        const role = document.getElementById('new-role').value;

        try {
            const response = await apiRequest('/users/register', 'POST', {
                username, email, password, role
            });

            if (response.success) {
                showNotification('User created successfully', 'success');
                loadUsers();
                return true;
            } else {
                showNotification(response.error || 'Failed to create user', 'error');
                return false;
            }
        } catch (error) {
            showNotification('Error creating user', 'error');
            return false;
        }
    });
}

async function viewUser(id) {
    try {
        const response = await apiRequest(`/users/${id}`);
        if (response.success) {
            const user = response.user;
            createModal('User Details', `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Username:</strong> ${escapeHtml(user.username)}</p>
                        <p><strong>Email:</strong> ${escapeHtml(user.email)}</p>
                        <p><strong>Role:</strong> <span class="badge bg-primary">${escapeHtml(user.role)}</span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Status:</strong> <span class="badge ${user.online ? 'badge-online' : 'badge-offline'}">${user.online ? 'Online' : 'Offline'}</span></p>
                        <p><strong>Active:</strong> ${user.active ? 'Yes' : 'No'}</p>
                        <p><strong>Last Seen:</strong> ${formatDate(user.lastSeen)}</p>
                    </div>
                </div>
                <hr>
                <p><strong>Created:</strong> ${formatDate(user.createdAt)}</p>
                <p><strong>Last Login:</strong> ${formatDate(user.lastLogin)}</p>
                ${user.customStatus ? `<p><strong>Status:</strong> ${escapeHtml(user.customStatus)}</p>` : ''}
            `, null, false);
        }
    } catch (error) {
        showNotification('Error loading user details', 'error');
    }
}

async function editUser(id) {
    try {
        const response = await apiRequest(`/users/${id}`);
        if (response.success) {
            const user = response.user;
            createModal('Edit User', `
                <form id="edit-user-form">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" value="${escapeHtml(user.username)}" disabled>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select class="form-select" id="edit-role">
                            <option value="user" ${user.role === 'user' ? 'selected' : ''}>User</option>
                            <option value="moderator" ${user.role === 'moderator' ? 'selected' : ''}>Moderator</option>
                            <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>Admin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="edit-active" ${user.active ? 'checked' : ''}>
                            <label class="form-check-label" for="edit-active">Active</label>
                        </div>
                    </div>
                </form>
            `, async () => {
                const role = document.getElementById('edit-role').value;
                const active = document.getElementById('edit-active').checked;

                const updateRes = await apiRequest(`/users/${id}`, 'PUT', { role, active });
                if (updateRes.success) {
                    showNotification('User updated successfully', 'success');
                    loadUsers();
                    return true;
                } else {
                    showNotification('Failed to update user', 'error');
                    return false;
                }
            });
        }
    } catch (error) {
        showNotification('Error loading user', 'error');
    }
}

async function deleteUser(id, username) {
    if (confirm(`Are you sure you want to delete user "${username}"? This action cannot be undone.`)) {
        try {
            const response = await apiRequest(`/users/${id}`, 'DELETE');
            if (response.success) {
                showNotification('User deleted successfully', 'success');
                loadUsers();
            } else {
                showNotification('Failed to delete user', 'error');
            }
        } catch (error) {
            showNotification('Error deleting user', 'error');
        }
    }
}

// Apps Management
async function loadApps() {
    const grid = document.getElementById('apps-grid');
    grid.innerHTML = '<div class="col-12 text-center"><div class="spinner-border"></div><p class="mt-2 text-muted">Loading apps...</p></div>';

    try {
        const response = await apiRequest('/apps');

        if (response.success && response.apps) {
            if (response.apps.length === 0) {
                grid.innerHTML = '<div class="col-12 text-center text-muted">No apps registered yet. Create your first app!</div>';
                return;
            }

            grid.innerHTML = response.apps.map(app => `
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="bi bi-grid-3x3-gap me-2"></i>
                                ${escapeHtml(app.name)}
                            </h5>
                            <p class="card-text text-muted">${escapeHtml(app.description || 'No description')}</p>
                            <div class="mb-3">
                                <span class="badge ${app.active ? 'bg-success' : 'bg-secondary'}">
                                    ${app.active ? 'Active' : 'Inactive'}
                                </span>
                                <span class="badge bg-info ms-2">
                                    <i class="bi bi-graph-up"></i> ${app.stats?.apiCalls || 0} calls
                                </span>
                            </div>
                            <div class="d-grid gap-2">
                                <button class="btn btn-sm btn-primary" onclick="viewApp('${app.id}')">
                                    <i class="bi bi-eye"></i> View Details
                                </button>
                                <button class="btn btn-sm btn-info" onclick="generateSDK('${app.id}', '${escapeHtml(app.name)}')">
                                    <i class="bi bi-code-square"></i> Generate SDK
                                </button>
                                <button class="btn btn-sm btn-warning" onclick="editApp('${app.id}')">
                                    <i class="bi bi-pencil"></i> Edit
                                </button>
                            </div>
                        </div>
                        <div class="card-footer text-muted">
                            <small>Created ${formatDate(app.createdAt)}</small>
                        </div>
                    </div>
                </div>
            `).join('');
        } else {
            grid.innerHTML = '<div class="col-12 text-center text-danger">Failed to load apps</div>';
        }
    } catch (error) {
        grid.innerHTML = '<div class="col-12 text-center text-danger">Error loading apps</div>';
        console.error('Load apps error:', error);
    }
}

function showCreateAppModal() {
    createModal('Register New App', `
        <form id="create-app-form">
            <div class="mb-3">
                <label class="form-label">App Name *</label>
                <input type="text" class="form-control" id="new-app-name" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea class="form-control" id="new-app-description" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Webhook URL (optional)</label>
                <input type="url" class="form-control" id="new-app-webhook" placeholder="https://example.com/webhook">
            </div>
        </form>
    `, async () => {
        const name = document.getElementById('new-app-name').value;
        const description = document.getElementById('new-app-description').value;
        const webhookUrl = document.getElementById('new-app-webhook').value;

        try {
            const response = await apiRequest('/apps/register', 'POST', {
                name, description, webhookUrl
            });

            if (response.success) {
                showNotification(`App created! API Key: ${response.app.apiKey}`, 'success');
                loadApps();

                // Show API key
                setTimeout(() => {
                    createModal('App Created Successfully', `
                        <div class="alert alert-success">
                            <h5>App registered successfully!</h5>
                            <p><strong>App Name:</strong> ${escapeHtml(name)}</p>
                            <p><strong>API Key:</strong></p>
                            <div class="input-group">
                                <input type="text" class="form-control" value="${response.app.apiKey}" id="api-key-display" readonly>
                                <button class="btn btn-outline-secondary" onclick="copyToClipboard('api-key-display')">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </div>
                            <p class="mt-2 text-warning"><i class="bi bi-exclamation-triangle"></i> Save this API key securely. You won't be able to see it again!</p>
                        </div>
                    `, null, false);
                }, 500);

                return true;
            } else {
                showNotification(response.error || 'Failed to create app', 'error');
                return false;
            }
        } catch (error) {
            showNotification('Error creating app', 'error');
            return false;
        }
    });
}

async function viewApp(id) {
    try {
        const response = await apiRequest(`/apps/${id}`);
        if (response.success) {
            const app = response.app;
            createModal('App Details', `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Name:</strong> ${escapeHtml(app.name)}</p>
                        <p><strong>Description:</strong> ${escapeHtml(app.description || 'N/A')}</p>
                        <p><strong>Status:</strong> <span class="badge ${app.active ? 'bg-success' : 'bg-secondary'}">${app.active ? 'Active' : 'Inactive'}</span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>API Calls:</strong> ${app.stats?.apiCalls || 0}</p>
                        <p><strong>Errors:</strong> ${app.stats?.errors || 0}</p>
                        <p><strong>Last API Call:</strong> ${formatDate(app.stats?.lastApiCall)}</p>
                    </div>
                </div>
                <hr>
                <p><strong>API Key:</strong></p>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" value="${app.apiKey}" id="app-api-key" readonly>
                    <button class="btn btn-outline-secondary" onclick="togglePasswordVisibility('app-api-key')">
                        <i class="bi bi-eye"></i>
                    </button>
                    <button class="btn btn-outline-secondary" onclick="copyToClipboard('app-api-key')">
                        <i class="bi bi-clipboard"></i>
                    </button>
                </div>
                <p><strong>Webhook URL:</strong> ${escapeHtml(app.webhookUrl || 'Not configured')}</p>
                <p><strong>Created:</strong> ${formatDate(app.createdAt)}</p>
            `, null, false);
        }
    } catch (error) {
        showNotification('Error loading app details', 'error');
    }
}

async function editApp(id) {
    try {
        const response = await apiRequest(`/apps/${id}`);
        if (response.success) {
            const app = response.app;
            createModal('Edit App', `
                <form id="edit-app-form">
                    <div class="mb-3">
                        <label class="form-label">App Name</label>
                        <input type="text" class="form-control" id="edit-app-name" value="${escapeHtml(app.name)}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" id="edit-app-description" rows="3">${escapeHtml(app.description || '')}</textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Webhook URL</label>
                        <input type="url" class="form-control" id="edit-app-webhook" value="${escapeHtml(app.webhookUrl || '')}">
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="edit-app-active" ${app.active ? 'checked' : ''}>
                            <label class="form-check-label" for="edit-app-active">Active</label>
                        </div>
                    </div>
                </form>
            `, async () => {
                const name = document.getElementById('edit-app-name').value;
                const description = document.getElementById('edit-app-description').value;
                const webhookUrl = document.getElementById('edit-app-webhook').value;
                const active = document.getElementById('edit-app-active').checked;

                const updateRes = await apiRequest(`/apps/${id}`, 'PUT', { name, description, webhookUrl, active });
                if (updateRes.success) {
                    showNotification('App updated successfully', 'success');
                    loadApps();
                    return true;
                } else {
                    showNotification('Failed to update app', 'error');
                    return false;
                }
            });
        }
    } catch (error) {
        showNotification('Error loading app', 'error');
    }
}

async function generateSDK(id, appName) {
    try {
        showNotification('Generating SDK...', 'info');
        const response = await apiRequest(`/apps/${id}/generate-sdk`, 'POST', {
            baseUrl: window.location.origin
        });

        if (response.success) {
            const sdk = response.sdk;
            createModal(`SDK Configuration - ${appName}`, `
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i> Copy this configuration to integrate your app with the server.
                </div>
                <pre class="bg-dark text-light p-3 rounded" style="max-height: 400px; overflow-y: auto;"><code id="sdk-code">${JSON.stringify(sdk, null, 2)}</code></pre>
                <button class="btn btn-primary w-100" onclick="copyToClipboard('sdk-code')">
                    <i class="bi bi-clipboard"></i> Copy to Clipboard
                </button>
            `, null, false);
            showNotification('SDK generated successfully', 'success');
        } else {
            showNotification('Failed to generate SDK', 'error');
        }
    } catch (error) {
        showNotification('Error generating SDK', 'error');
    }
}

// Database Management
async function loadDatabase() {
    const container = document.getElementById('collections-list');
    container.innerHTML = '<div class="text-center"><div class="spinner-border"></div><p class="mt-2 text-muted">Loading collections...</p></div>';

    try {
        const response = await apiRequest('/database/collections');

        if (response.success && response.collections) {
            if (response.collections.length === 0) {
                container.innerHTML = '<div class="alert alert-info">No collections yet. Create your first collection!</div>';
                return;
            }

            container.innerHTML = response.collections.map(collection => `
                <div class="card mb-3">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="bi bi-collection"></i> ${escapeHtml(collection.name)}
                        </h5>
                        <div>
                            <span class="badge bg-info me-2">${collection.documentCount} documents</span>
                            <button class="btn btn-sm btn-primary" onclick="viewCollection('${escapeHtml(collection.name)}')">
                                <i class="bi bi-eye"></i> View
                            </button>
                            <button class="btn btn-sm btn-success" onclick="insertDocument('${escapeHtml(collection.name)}')">
                                <i class="bi bi-plus-circle"></i> Add Document
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="dropCollection('${escapeHtml(collection.name)}')">
                                <i class="bi bi-trash"></i> Drop
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="mb-2"><strong>Schema:</strong></p>
                        <pre class="bg-dark text-light p-2 rounded" style="max-height: 150px; overflow-y: auto;"><code>${JSON.stringify(collection.schema, null, 2)}</code></pre>
                    </div>
                </div>
            `).join('');
        } else {
            container.innerHTML = '<div class="alert alert-danger">Failed to load collections</div>';
        }
    } catch (error) {
        container.innerHTML = '<div class="alert alert-danger">Error loading collections</div>';
        console.error('Load database error:', error);
    }
}

function showCreateCollectionModal() {
    createModal('Create Collection', `
        <form id="create-collection-form">
            <div class="mb-3">
                <label class="form-label">Collection Name *</label>
                <input type="text" class="form-control" id="new-collection-name" required placeholder="e.g., products">
            </div>
            <div class="mb-3">
                <label class="form-label">Schema (JSON)</label>
                <textarea class="form-control font-monospace" id="new-collection-schema" rows="10" placeholder='{\n  "fields": {\n    "name": { "type": "string", "required": true }\n  },\n  "indexes": ["name"]\n}'></textarea>
                <small class="text-muted">Leave empty for no schema validation</small>
            </div>
        </form>
    `, async () => {
        const name = document.getElementById('new-collection-name').value;
        const schemaText = document.getElementById('new-collection-schema').value;

        let schema = {};
        if (schemaText.trim()) {
            try {
                schema = JSON.parse(schemaText);
            } catch (e) {
                showNotification('Invalid JSON schema', 'error');
                return false;
            }
        }

        try {
            const response = await apiRequest('/database/collections', 'POST', { name, schema });
            if (response.success) {
                showNotification('Collection created successfully', 'success');
                loadDatabase();
                return true;
            } else {
                showNotification(response.error || 'Failed to create collection', 'error');
                return false;
            }
        } catch (error) {
            showNotification('Error creating collection', 'error');
            return false;
        }
    });
}

async function viewCollection(name) {
    try {
        const response = await apiRequest(`/database/collections/${name}/documents?limit=50`);
        if (response.success) {
            createModal(`Collection: ${name}`, `
                <div class="mb-3">
                    <strong>Total Documents:</strong> ${response.total}
                </div>
                <div style="max-height: 500px; overflow-y: auto;">
                    <pre class="bg-dark text-light p-3 rounded"><code>${JSON.stringify(response.documents, null, 2)}</code></pre>
                </div>
            `, null, false);
        }
    } catch (error) {
        showNotification('Error loading collection', 'error');
    }
}

function insertDocument(collectionName) {
    createModal(`Insert Document - ${collectionName}`, `
        <form id="insert-document-form">
            <div class="mb-3">
                <label class="form-label">Document (JSON) *</label>
                <textarea class="form-control font-monospace" id="new-document-data" rows="10" required placeholder='{\n  "name": "Example",\n  "value": 123\n}'></textarea>
            </div>
        </form>
    `, async () => {
        const dataText = document.getElementById('new-document-data').value;

        let data;
        try {
            data = JSON.parse(dataText);
        } catch (e) {
            showNotification('Invalid JSON', 'error');
            return false;
        }

        try {
            const response = await apiRequest(`/database/collections/${collectionName}/documents`, 'POST', data);
            if (response.success) {
                showNotification('Document inserted successfully', 'success');
                loadDatabase();
                return true;
            } else {
                showNotification(response.error || 'Failed to insert document', 'error');
                return false;
            }
        } catch (error) {
            showNotification('Error inserting document', 'error');
            return false;
        }
    });
}

async function dropCollection(name) {
    if (confirm(`Are you sure you want to drop collection "${name}"? This will delete all documents and cannot be undone!`)) {
        try {
            const response = await apiRequest(`/database/collections/${name}`, 'DELETE');
            if (response.success) {
                showNotification('Collection dropped successfully', 'success');
                loadDatabase();
            } else {
                showNotification('Failed to drop collection', 'error');
            }
        } catch (error) {
            showNotification('Error dropping collection', 'error');
        }
    }
}

async function backupDatabase() {
    try {
        showNotification('Creating backup...', 'info');
        const response = await apiRequest('/database/backup', 'POST', {
            name: `backup-${Date.now()}`
        });
        if (response.success) {
            showNotification(`Backup created: ${response.backupPath}`, 'success');
        } else {
            showNotification('Failed to create backup', 'error');
        }
    } catch (error) {
        showNotification('Error creating backup', 'error');
    }
}

async function exportDatabase() {
    try {
        showNotification('Exporting database...', 'info');
        const response = await apiRequest('/database/export');
        if (response.success) {
            const dataStr = JSON.stringify(response.data, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(dataBlob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `database-export-${Date.now()}.json`;
            link.click();
            showNotification('Database exported successfully', 'success');
        } else {
            showNotification('Failed to export database', 'error');
        }
    } catch (error) {
        showNotification('Error exporting database', 'error');
    }
}

// AI Functions
async function generateSchema() {
    const prompt = document.getElementById('ai-schema-prompt').value;
    const resultDiv = document.getElementById('ai-schema-result');

    if (!prompt) {
        showNotification('Please enter a prompt', 'warning');
        return;
    }

    resultDiv.innerHTML = '<div class="spinner-border spinner-border-sm"></div> Generating schema with AI...';

    try {
        const response = await apiRequest('/database/collections/generate', 'POST', { prompt });

        if (response.success) {
            const schema = response.schema;
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <h6><i class="bi bi-check-circle"></i> Schema Generated Successfully!</h6>
                    <pre class="bg-dark text-light p-3 rounded mt-2" style="max-height: 300px; overflow-y: auto;"><code>${JSON.stringify(schema, null, 2)}</code></pre>
                    <button class="btn btn-sm btn-primary mt-2" onclick='applyGeneratedSchema(${JSON.stringify(JSON.stringify(schema))})'>
                        <i class="bi bi-check"></i> Apply This Schema
                    </button>
                </div>
            `;
            showNotification('Schema generated successfully!', 'success');
        } else {
            resultDiv.innerHTML = `<div class="alert alert-danger">${escapeHtml(response.error || 'Failed to generate schema')}</div>`;
            showNotification('Failed to generate schema', 'error');
        }
    } catch (error) {
        resultDiv.innerHTML = `<div class="alert alert-danger">Error: ${escapeHtml(error.message)}</div>`;
        showNotification('Error generating schema', 'error');
    }
}

async function applyGeneratedSchema(schemaJson) {
    const schema = JSON.parse(schemaJson);

    if (confirm(`Apply schema for collection "${schema.collectionName}"?`)) {
        try {
            const response = await apiRequest('/database/collections/apply-generated', 'POST', {
                collectionName: schema.collectionName,
                schema: schema.schema
            });

            if (response.success) {
                showNotification('Schema applied successfully!', 'success');
                navigateToPage('database');
            } else {
                showNotification(response.error || 'Failed to apply schema', 'error');
            }
        } catch (error) {
            showNotification('Error applying schema', 'error');
        }
    }
}

async function generateApp() {
    const prompt = document.getElementById('ai-app-prompt').value;
    const resultDiv = document.getElementById('ai-app-result');

    if (!prompt) {
        showNotification('Please enter a prompt', 'warning');
        return;
    }

    resultDiv.innerHTML = '<div class="spinner-border spinner-border-sm"></div> Generating app with AI...';

    try {
        const response = await apiRequest('/ai/generate-app', 'POST', { description: prompt });

        if (response.success) {
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <h6><i class="bi bi-check-circle"></i> App Generated Successfully!</h6>
                    <pre class="bg-dark text-light p-3 rounded mt-2" style="max-height: 400px; overflow-y: auto;"><code>${JSON.stringify(response.appSpec, null, 2)}</code></pre>
                </div>
            `;
            showNotification('App specification generated!', 'success');
        } else {
            resultDiv.innerHTML = `<div class="alert alert-danger">${escapeHtml(response.error || 'Failed to generate app')}</div>`;
            showNotification('Failed to generate app', 'error');
        }
    } catch (error) {
        resultDiv.innerHTML = `<div class="alert alert-danger">Error: ${escapeHtml(error.message)}</div>`;
        showNotification('Error generating app', 'error');
    }
}

async function getOptimizations() {
    const resultDiv = document.getElementById('ai-optimizations');
    resultDiv.innerHTML = '<div class="spinner-border spinner-border-sm"></div> Getting optimization suggestions...';

    try {
        const response = await apiRequest('/ai/optimize', 'POST', {
            context: {
                server: 'universal-server',
                version: '1.0.0',
                currentPage: currentPage
            }
        });

        if (response.success) {
            const suggestions = response.suggestions?.suggestions || [];
            resultDiv.innerHTML = `
                <div class="alert alert-info">
                    <h6><i class="bi bi-lightbulb"></i> Optimization Suggestions</h6>
                    ${suggestions.length > 0 ? suggestions.map(s => `
                        <div class="mt-3 p-3 bg-dark rounded">
                            <h6><span class="badge bg-${s.priority === 'high' ? 'danger' : s.priority === 'medium' ? 'warning' : 'info'}">${s.priority}</span> ${s.title}</h6>
                            <p class="mb-2">${s.description}</p>
                            <small class="text-muted"><strong>Implementation:</strong> ${s.implementation}</small>
                        </div>
                    `).join('') : '<p>No specific suggestions at this time.</p>'}
                </div>
            `;
            showNotification('Suggestions loaded!', 'success');
        } else {
            resultDiv.innerHTML = `<div class="alert alert-danger">${escapeHtml(response.error || 'Failed to get suggestions')}</div>`;
        }
    } catch (error) {
        resultDiv.innerHTML = `<div class="alert alert-danger">Error: ${escapeHtml(error.message)}</div>`;
    }
}

// Realtime Monitor
async function loadRealtime() {
    const container = document.getElementById('realtime-content');
    if (!container) return;

    container.innerHTML = '<div class="text-center"><div class="spinner-border"></div><p class="mt-2">Loading realtime stats...</p></div>';

    try {
        const response = await apiRequest('/realtime/stats');
        if (response.success) {
            const stats = response.stats;
            container.innerHTML = `
                <div class="row g-4">
                    <div class="col-md-3">
                        <div class="card stat-card">
                            <div class="card-body text-center">
                                <h2>${stats.totalConnections}</h2>
                                <p class="mb-0">Total Connections</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card success">
                            <div class="card-body text-center">
                                <h2>${stats.authenticatedConnections}</h2>
                                <p class="mb-0">Authenticated</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card warning">
                            <div class="card-body text-center">
                                <h2>${stats.uniqueUsers}</h2>
                                <p class="mb-0">Unique Users</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card info">
                            <div class="card-body text-center">
                                <h2>${stats.uniqueApps}</h2>
                                <p class="mb-0">Connected Apps</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="mb-0">Active Users</h5>
                    </div>
                    <div class="card-body">
                        <p class="text-muted">Real-time user monitoring coming soon...</p>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        container.innerHTML = '<div class="alert alert-danger">Error loading realtime stats</div>';
    }
}

// Logs
async function loadLogs() {
    const container = document.getElementById('logs-content');
    if (!container) return;

    container.innerHTML = `
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">System Logs</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i> Log viewing feature coming soon. Logs are currently stored in <code>./logs/server.log</code>
                </div>
            </div>
        </div>
    `;
}

// Utility Functions
async function apiRequest(endpoint, method = 'GET', body = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
        }
    };

    if (body) {
        options.body = JSON.stringify(body);
    }

    const response = await fetch(`${API_BASE}${endpoint}`, options);

    if (response.status === 401) {
        logout();
        throw new Error('Unauthorized');
    }

    return response.json();
}

function formatDate(dateString) {
    if (!dateString) return 'Never';
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`;
    return date.toLocaleDateString();
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function toggleTheme() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-bs-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-bs-theme', newTheme);
    document.getElementById('theme-text').textContent = newTheme === 'dark' ? 'Dark Mode' : 'Light Mode';
    localStorage.setItem('theme', newTheme);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function copyToClipboard(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        const text = element.value || element.textContent;
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Copied to clipboard!', 'success');
        }).catch(() => {
            showNotification('Failed to copy', 'error');
        });
    }
}

function togglePasswordVisibility(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.type = element.type === 'password' ? 'text' : 'password';
    }
}

// Modal System
function createModal(title, content, onSave = null, showSaveButton = true) {
    // Remove existing modal
    const existingModal = document.getElementById('dynamic-modal');
    if (existingModal) {
        existingModal.remove();
    }

    const modalHtml = `
        <div class="modal fade" id="dynamic-modal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        ${content}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        ${showSaveButton ? '<button type="button" class="btn btn-primary" id="modal-save-btn">Save</button>' : ''}
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    const modalElement = document.getElementById('dynamic-modal');
    const modal = new bootstrap.Modal(modalElement);

    if (showSaveButton && onSave) {
        document.getElementById('modal-save-btn').addEventListener('click', async () => {
            const saveBtn = document.getElementById('modal-save-btn');
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Saving...';

            const result = await onSave();
            if (result !== false) {
                modal.hide();
            } else {
                saveBtn.disabled = false;
                saveBtn.innerHTML = 'Save';
            }
        });
    }

    modalElement.addEventListener('hidden.bs.modal', () => {
        modalElement.remove();
    });

    modal.show();
    return modal;
}

// Notification System
function showNotification(message, type = 'info') {
    const notificationHtml = `
        <div class="toast align-items-center text-white bg-${type === 'success' ? 'success' : type === 'error' ? 'danger' : type === 'warning' ? 'warning' : 'info'} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="bi bi-${type === 'success' ? 'check-circle' : type === 'error' ? 'x-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;

    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
    }

    container.insertAdjacentHTML('beforeend', notificationHtml);
    const toastElement = container.lastElementChild;
    const toast = new bootstrap.Toast(toastElement, { delay: 3000 });
    toast.show();

    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });
}

// Initialize theme from localStorage
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.documentElement.setAttribute('data-bs-theme', savedTheme);
    const themeText = document.getElementById('theme-text');
    if (themeText) {
        themeText.textContent = savedTheme === 'dark' ? 'Dark Mode' : 'Light Mode';
    }
}
